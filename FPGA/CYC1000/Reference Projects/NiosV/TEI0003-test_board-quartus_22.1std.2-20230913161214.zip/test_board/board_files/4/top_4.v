//
//  TEI0003 - CYC1000 - 4
// 

module top_4
(
  // clock
  input     CLK12M,
  
  // user button
  input			USER_BTN,
  
  // user leds
  output			LED1,
  output			LED2,
  output			LED3,
  output			LED4,
  output			LED5,
  output			LED6,
  output			LED7,
  output			LED8,
  
  // FTDI - UART - Channel B
  input     BDBUS0, //FPGA_RXD
  output    BDBUS1, //FPGA_TXD
  // input			BDBUS2, // RTS#
  // output			BDBUS3, // CTS#
  // input			BDBUS4, // DTR#
  // output			BDBUS5, // DSR#
  // FTDI - Channel A
  // input			ADBUS4, // GPIOL0
  // input			ADBUS7, // GPIOL3
  
  // 3-axis accelerometer
  output    SEN_CS,
  output    SEN_SDI,
  input     SEN_SDO,
  output    SEN_SPC,
  input     SEN_INT1,
  input     SEN_INT2,
  
  // sdram memory
  input     CKE,
  output    CLK,
  input     CAS,
  input     CS,
  input     WE,
  input     RAS,
  output  [1:0]   DQM,
  inout   [15:0]  DQ,
  output  [1:0]   BA,
  output  [11:0]  A
  
  // Pin Header J6 I/O
  // input/output     PIO_01,
  // input/output     PIO_02,
  // input/output     PIO_03,
  // input/output     PIO_04,
  // input/output     PIO_05,
  // input/output     PIO_06,
  // input/output     PIO_07,
  // input/output     PIO_08,
  
  // Pin Header J1 
  // input/output     AIN0,
  // input/output     AIN1,
  // input/output     AIN2,
  // input/output     AIN3,
  // input/output     AIN4,
  // input/output     AIN5,
  // input/output     AIN6,
  // input/output     AIN7,
  
  // Pin Header J1/J2 I/O
  // input/output     D0,
  // input/output     D1,
  // input/output     D2,
  // input/output     D3,
  // input/output     D4,
  // input/output     D5,
  // input/output     D6,
  // input/output     D7,
  // input/output     D8,
  // input/output     D9,
  // input/output     D10,
  // input/output     D11,
  // input/output     D11_R,
  // input/output     D12,
  // input/output     D12_R,
  // input/output     D13,
  // input/output     D14

);

endmodule
