/*
 * Hello Trenz Module(TEI0003)
 *
 * Description:
 * Hello World example for TEI0003 with endless loop running on SDRAM memory
 *
 */

#include <stdio.h>
#include <unistd.h>

int main()
{
    int print_index = 0;
    while (1)
    {
		print_index++;
    	printf("Hello Trenz Module(TEI0003) (Loop: %i)\n\r", print_index);
    	usleep(750000);
    }

    return 0;
}
