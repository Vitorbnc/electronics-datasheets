# # --------------------------------------------------------------------
# # --   *****************************
# # --   *   Trenz Electronic GmbH   *
# # --   *   Holzweg 19A             *
# # --   *   32257 Bünde   		    *
# # --   *   Germany                 *
# # --   *****************************
# # --------------------------------------------------------------------
# # --$Autor: Dück, Thomas $
# # --$Email: t.dueck@trenz-electronic.de $
# # --$Create Date: 2019/11/07 $
# # --$Modify Date: 2019/11/07 $
# # --$Version: 1.0 $
# # --	$initial release 18.1
# # --------------------------------------------------------------------
# # --------------------------------------------------------------------
function quartus_start {
	echo "Start create project..."
	echo "----------------------- Create log folder ---------------------------"
	# log folder
	log_folder=${bashfile_path}/log
	echo "${log_folder}"
	if [ -d "$log_folder" ]; then
		rm -rf ${log_folder}
	fi
	mkdir ${log_folder}   
	echo "--------------------------------------------------------------------"

	echo "----------------------- Start Quartus scripts ----------------------"
	${QUADIR}/${QUARTUS_VERSION}/nios2eds/nios2_command_shell.sh quartus_sh -t scripts/script_main.tcl  --run 1 --gui 0 --clean 3 --boardpart ${PARTNUMBER}  
	echo "-------------------------scripts finished---------------------------"
	echo "--------------------------------------------------------------------"
	echo "------------------------Design finished-----------------------------"

}

echo "------------------------Set design paths----------------------------"
# get paths
bashfile_name=${0##*/}
bashfile_path=`dirname $0`

cd $bashfile_path

echo "-- Run Design with: ${bashfile_name}"
echo "-- Use Design Path: ${bashfile_path}"
echo "---------------------Load basic design settings---------------------"
source $bashfile_path/design_basic_settings.sh
echo "--------------------------------------------------------------------"
echo "----------------- Set Quartus environment variables ----------------"
echo "-- Use QUARTUS Version: ${QUARTUS_VERSION} --"
echo "--------------------------------------------------------------------"


echo "------------------- check old project exists -----------------------"
quartus_p_folder=${bashfile_path}/quartus
if !  [ -e "${QUADIR}" ]; then  
	echo "-- Error: ${QUADIR} not found. Check path of QUADIR variable on design_basic_settings.sh (upper and lower case is important)"
	echo "---------------------------Error occurs-----------------------------"
	echo "--------------------------------------------------------------------"
else
	if [ -d "$quartus_p_folder" ]; then
		echo "Found old quartus project: Create project will delete old project!"
		echo "Are you sure to continue? (y/N):"
		read createProject
		if [ ${createProject} == y ] || [ ${createProject} == Y ]; then
			quartus_start
		else
			echo "Create Quartus project is canceled."
		fi
	else
		quartus_start
	fi
fi
