@REM # --------------------------------------------------------------------
@REM # --   *****************************
@REM # --   *   Trenz Electronic GmbH   *
@REM # --   *   Holzweg 19A             *
@REM # --   *   32257 Bünde   		    *
@REM # --   *   Germany                 *
@REM # --   *****************************
@REM # --------------------------------------------------------------------
@REM # --$Autor: Dück, Thomas $
@REM # --$Email: t.dueck@trenz-electronic.de $
@REM # --$Create Date: 2019/10/25 $
@REM # --$Modify Date: 2019/10/25 $
@REM # --$Version: 1.0 $
@REM # --	$initial release 18.1
@REM # --------------------------------------------------------------------
@REM # --------------------------------------------------------------------
@REM set local environment
setlocal
@echo ------------------------Set design paths----------------------------
@REM get paths
@set batchfile_name=%~n0
@set batchfile_drive=%~d0
@set batchfile_path=%~dp0
@REM change drive
@%batchfile_drive%
@REM change path to batchfile folder
@cd %batchfile_path%
@echo -- Run Design with: %batchfile_name%
@echo -- Use Design Path: %batchfile_path%
@echo ---------------------Load basic design settings---------------------
@call design_basic_settings.cmd
@echo --------------------------------------------------------------------
@echo ----------------------- Create log folder ---------------------------
@REM log folder
@set log_folder=%batchfile_path%log
@echo %log_folder%
@if not exist %log_folder% ( @mkdir %log_folder% )


@REM # --------------------
@echo -- Use Quartus Version: %QUARTUS_VERSION% --

@echo --------------------------------------------------------------------

@if exist %QUADIR% (
  @echo Use Quartus installation from '%QUADIR%'
  @goto RUN
)

@if not exist %QUADIR% ( 
	@echo -- Error: %QUADIR% not found. Check path of QUADIR variable on design_basic_settings.cmd (upper and lower case is important)
	@goto ERROR
)


:RUN  
@echo --------------------------------------------------------------------
@echo -------------------------Start Quartus scripts -----------------------
"%QUADIR%/%QUARTUS_VERSION%/nios2eds/Nios II Command Shell.bat" quartus_sh -t scripts/script_main.tcl --gui 1
@echo -------------------------scripts finished----------------------------
@echo --------------------------------------------------------------------
@echo --------------------Change to design folder-------------------------
@cd..
@echo ------------------------Design finished-----------------------------
@if not defined DO_NOT_CLOSE_SHELL (
  @set DO_NOT_CLOSE_SHELL=0
)
@if %DO_NOT_CLOSE_SHELL%==1 (
  PAUSE
)
GOTO EOF

:ERROR
@echo ---------------------------Error occurs-----------------------------
@echo --------------------------------------------------------------------
PAUSE

:EOF