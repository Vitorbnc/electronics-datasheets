@REM # --------------------------------------------------------------------
@REM # --   *****************************
@REM # --   *   Trenz Electronic GmbH   *
@REM # --   *   Holzweg 19A             *
@REM # --   *   32257 B�nde             *
@REM # --   *   Germany                 *
@REM # --   *****************************
@REM # --------------------------------------------------------------------
@REM # --$Autor: D�ck, Thomas $
@REM # --$Email: t.dueck@trenz-electronic.de $
@REM # --$Create Date: 2019/10/25 $
@REM # --$Modify Date: 2019/10/25 $
@REM # --$Version: 1.0 $


@REM # --------------------------------------------------------------------
@REM # Additional description on: https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices
@REM # --------------------------------------------------------------------
@REM # Important Settings:
@REM # -------------------------
@REM --------------------
@REM Set Quartus Installation path:
@REM    -The scripts search for Quartus software on this paths:
@REM    -Quartus (recommend used for project creation and programming): %QUADIR%\%QUARTUS_VERSION%\
@REM -Important Note: Check if Quartus default install path use upper or lower case
@set QUADIR=C:/intelFPGA_lite
@REM -Attention: These scripts support only the predefined Quartus Version. 
@set QUARTUS_VERSION=18.1
@REM --------------------
@REM Set device FPGA family and device of the project which should be created
@REM    -Available Numbers: (you can use ID,PRODID from \board_files\TEIxxxx_devices.csv list) or
@REM 	 special name "LAST_ID" to get the board with the highest ID in the *.csv list
@REM    -variable is used for project creation and programming
@REM    -Example: set PARTNUMBER=TEI0001-02-16-C8 || @set PARTNUMBER=1
@set PARTNUMBER=LAST_ID
@REM --------------------
@REM # --------------------------------------------------------------------
@REM # Optional Settings:
@REM # -------------------------
@REM --------------------
@REM Do not close shell after processing
@REM  -Example: @set DO_NOT_CLOSE_SHELL=1, Shell will not be closed
@REM            @set DO_NOT_CLOSE_SHELL=0, Shell will be closed automatically
@set DO_NOT_CLOSE_SHELL=0
@REM --------------------
