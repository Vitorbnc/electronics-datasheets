@REM # --------------------------------------------------------------------
@REM # --   *****************************
@REM # --   *   Trenz Electronic GmbH   *
@REM # --   *   Holzweg 19A             *
@REM # --   *   32257 Bünde   		    *
@REM # --   *   Germany                 *
@REM # --   *****************************
@REM # --------------------------------------------------------------------
@REM # --$Autor: Dück, Thomas $
@REM # --$Email: t.dueck@trenz-electronic.de $
@REM # --$Create Date: 2019/10/25 $
@REM # --$Modify Date: 2019/10/25 $
@REM # --$Version: 1.0 $
@REM #    -- initial release 18.1
@REM # --------------------------------------------------------------------
@REM # --------------------------------------------------------------------
@REM resize window
@mode con: cols=200 lines=50
@powershell -noprofile "$W=(get-host).ui.rawui; $B=$W.buffersize; $B.height=10000; $W.buffersize=$B"

@REM set local environment
setlocal

@echo ------------------------Set design paths----------------------------
@REM get paths
@set batchfile_name=%~n0
@set batchfile_drive=%~d0
@set batchfile_path=%~dp0
@REM change drive
@%batchfile_drive%
@REM change path to batchfile folder
@cd %batchfile_path%
@echo -- Run Design with: %batchfile_name%
@echo -- Use Design Path: %batchfile_path%
@set cmd_folder=%batchfile_path%console\base_cmd\

@REM ------------------------------------------------------------------------------
:NEXT_TE_BASE
@echo -----------------------------------------------------------------------
@echo ------------------------ TE Reference Design --------------------------
@echo -----------------------------------------------------------------------
@echo -- (c)  Go to CMD-File Generation (Manual setup)
@echo -- (d)  Go to Documentation (Web Documentation)
@echo -- (x)  Exit Batch (nothing is done!)
@echo -- (0)  Module selection guide and project creation...
@echo -- (1)  Create minimum setup of CMD-Files and exit Batch   
@echo -- (2)  Create maximum setup of CMD-Files and exit Batch    
@echo -- (3)  (internal only) Dev    
@echo -- (4)  (internal only) Prod    
@echo ----
@set /p new_base=" Select (ex.:'0' for module selection guide):"
@if "%new_base%"=="d" (@GOTO NEXT_TE_DOC)
@if "%new_base%"=="c" (@GOTO NEXT_TE_CMD)
@if "%new_base%"=="x" (@GOTO EOF)
@if "%new_base%"=="0" (
	@set new_cmd=config
	@GOTO CONFIG_SETUP
)
@if "%new_base%"=="1" (
	@set new_cmd=min
	@GOTO MIN_SETUP
)
@if "%new_base%"=="2" (
	@set new_cmd=max
	@GOTO MAX_SETUP
)

@if "%new_base%"=="3" (
	@set new_cmd=development
	@GOTO DEVELOPMENT_SETUP
)

@if "%new_base%"=="4" (
	@set new_cmd=production
	@GOTO PRODUCTION_SETUP
)

@GOTO NEXT_TE_BASE
@echo --------------------------------------------------------------------
@REM ------------------------------------------------------------------------------
:NEXT_TE_DOC
@echo --------------------------------------------------------------------
@echo -------------------------TE Documentation---------------------------
@echo --------------------------------------------------------------------
@echo -- (b)  Go to Base Menue
@echo -- (x)  Exit Batch(nothing is done!)
@echo -- (0)  Trenz Electronic Wiki
@echo -- (1)  Trenz Electronic Wiki: Project Delivery - Intel devices
@echo -- (1a) Trenz Electronic Wiki: Project Delivery-Quick Start
@echo -- (1b) Trenz Electronic Wiki: Project Delivery-CMD Description
@echo -- (2)  Trenz Electronic Downloads
@echo ----
@set /p new_doc=" Select Document (ex.:'0' for Wiki ,'b' go to Base Menue):"
@if "%new_doc%"=="b" (@GOTO NEXT_TE_BASE)
@if "%new_doc%"=="x" (@GOTO EOF)
@if "%new_doc%"=="0" (@start https://wiki.trenz-electronic.de/display/PD/Trenz+Electronic+Documentation)
@if "%new_doc%"=="1" (@start https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices)
@if "%new_doc%"=="1a" (@start https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices#ProjectDelivery+Inteldevices-QuickStart)
@if "%new_doc%"=="1b" (@start https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices#ProjectDelivery+Inteldevices-WindowsCommandFiles)
@if "%new_doc%"=="2" (@start https://shop.trenz-electronic.de/en/Download/?path=Trenz_Electronic)
@GOTO NEXT_TE_DOC
@echo --------------------------------------------------------------------
@REM ------------------------------------------------------------------------------
:NEXT_TE_CMD
@if not exist %cmd_folder% (@GOTO ERROR)   
@echo --------------------------------------------------------------------
@echo --------------------------Create CMD Files--------------------------
@echo --------------------------------------------------------------------
@echo -- Available CMD Files:
@echo -- (b)  Go to Base Menue
@echo -- (x)  Exit CMD Generation
@REM @echo -- ( )  design_basic_settings.cmd (generated always, if not exist)
@echo -- (min)Generate minimum CMD setup                        (recommended)
@echo -- (max)Generate maximum CMD setup
@echo -- (1) development_design_run_prebuilt_all_batchmode.cmd  (not available)
@echo -- (2) development_utilities_backup.cmd                   (not available)
@echo -- (3) development_utilities_backup_noprebuilt.cmd        (not available)
@echo -- (4) development_utilities_generate_source_files.cmd    (not available)
@echo -- (5) quartus_create_project_batchmode.cmd
@echo -- (6) quartus_open_existing_project_guimode.cmd
@echo ----
@set /p new_cmd=" Select CMD Files (ex.:'min' for minimum setup, 'x' for exit):"
@if "%new_cmd%"=="b" (@GOTO NEXT_TE_BASE)
@if "%new_cmd%"=="x" (@GOTO LAST_DESCR)

:MIN_SETUP
@if "%new_cmd%"=="min" ( 
	@if exist %cmd_folder%quartus_create_project_batchmode.cmd		( @copy %cmd_folder%quartus_create_project_batchmode.cmd		%batchfile_path%quartus_create_project_batchmode.cmd)
	@if exist %cmd_folder%quartus_open_existing_project_guimode.cmd ( @copy %cmd_folder%quartus_open_existing_project_guimode.cmd	%batchfile_path%quartus_open_existing_project_guimode.cmd)
	@GOTO LAST_DESCR
)
:DEVELOPMENT_SETUP
@if "%new_cmd%"=="development" ( 
	@if exist %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd ( @copy %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd	%batchfile_path%development_design_run_prebuilt_all_batchmode.cmd)
	@if exist %cmd_folder%development_utilities_backup.cmd					( @copy %cmd_folder%development_utilities_backup.cmd					%batchfile_path%development_utilities_backup.cmd)
	@if exist %cmd_folder%development_utilities_backup_noprebuilt.cmd		( @copy %cmd_folder%development_utilities_backup_noprebuilt.cmd			%batchfile_path%development_utilities_backup_noprebuilt.cmd)
	@if exist %cmd_folder%development_utilities_generate_source_files.cmd	( @copy %cmd_folder%development_utilities_generate_source_files.cmd		%batchfile_path%development_utilities_generate_source_files.cmd)
	@if exist %cmd_folder%quartus_create_project_batchmode.cmd				( @copy %cmd_folder%quartus_create_project_batchmode.cmd				%batchfile_path%quartus_create_project_batchmode.cmd)
	@if exist %cmd_folder%quartus_open_existing_project_guimode.cmd			( @copy %cmd_folder%quartus_open_existing_project_guimode.cmd			%batchfile_path%quartus_open_existing_project_guimode.cmd)
	@GOTO LAST_DESCR
)
:PRODUCTION_SETUP
@if "%new_cmd%"=="production" ( 
	@GOTO LAST_DESCR
)

:MAX_SETUP
@if "%new_cmd%"=="max" ( 
	@if exist %cmd_folder%quartus_create_project_batchmode.cmd				( @copy %cmd_folder%quartus_create_project_batchmode.cmd				%batchfile_path%quartus_create_project_batchmode.cmd)
	@if exist %cmd_folder%quartus_open_existing_project_guimode.cmd			( @copy %cmd_folder%quartus_open_existing_project_guimode.cmd			%batchfile_path%quartus_open_existing_project_guimode.cmd)
	@if exist %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd ( @copy %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd	%batchfile_path%development_design_run_prebuilt_all_batchmode.cmd)
	@if exist %cmd_folder%development_utilities_backup.cmd					( @copy %cmd_folder%development_utilities_backup.cmd					%batchfile_path%development_utilities_backup.cmd)
	@if exist %cmd_folder%development_utilities_backup_noprebuilt.cmd		( @copy %cmd_folder%development_utilities_backup_noprebuilt.cmd			%batchfile_path%development_utilities_backup_noprebuilt.cmd)
	@if exist %cmd_folder%development_utilities_generate_source_files.cmd	( @copy %cmd_folder%development_utilities_generate_source_files.cmd		%batchfile_path%development_utilities_generate_source_files.cmd)
	@GOTO LAST_DESCR
)
@if "%new_cmd%"=="1" ( 
	@if exist %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd ( @copy %cmd_folder%development_design_run_prebuilt_all_batchmode.cmd	%batchfile_path%development_design_run_prebuilt_all_batchmode.cmd)
)
@if "%new_cmd%"=="2" ( 
	@if exist %cmd_folder%development_utilities_backup.cmd					( @copy %cmd_folder%development_utilities_backup.cmd					%batchfile_path%development_utilities_backup.cmd)
)
@if "%new_cmd%"=="3" ( 
	@if exist %cmd_folder%development_utilities_backup_noprebuilt.cmd		( @copy %cmd_folder%development_utilities_backup_noprebuilt.cmd			%batchfile_path%development_utilities_backup_noprebuilt.cmd)
)
@if "%new_cmd%"=="4" ( 
	@if exist %cmd_folder%development_utilities_generate_source_files.cmd	( @copy %cmd_folder%development_utilities_generate_source_files.cmd		%batchfile_path%development_utilities_generate_source_files.cmd)
)
@if "%new_cmd%"=="5" ( 
	@if exist %cmd_folder%quartus_create_project_batchmode.cmd				( @copy %cmd_folder%quartus_create_project_batchmode.cmd				%batchfile_path%quartus_create_project_batchmode.cmd)
)
@if "%new_cmd%"=="6" ( 
	@if exist %cmd_folder%quartus_open_existing_project_guimode.cmd			( @copy %cmd_folder%quartus_open_existing_project_guimode.cmd			%batchfile_path%quartus_open_existing_project_guimode.cmd)
)

@GOTO NEXT_TE_CMD


:CONFIG_SETUP
@if not exist %batchfile_path%design_basic_settings.cmd ( @copy %cmd_folder%design_basic_settings.cmd %batchfile_path%design_basic_settings.cmd)

@REM # load environment and check Quartus version
@call  %cmd_folder%design_basic_settings.cmd
@set DEF_QUARTUS_VERSION=%QUARTUS_VERSION%

@call design_basic_settings.cmd
@if  "%DEF_QUARTUS_VERSION%" NEQ "%QUARTUS_VERSION%" (
@echo -----------------------------------------
@echo Attention:
@echo  - Design was created for Quartus %DEF_QUARTUS_VERSION%, selected is Quartus %QUARTUS_VERSION%
@echo  - Design only tested with Quartus %DEF_QUARTUS_VERSION%, modifications needed for other versions
@echo .
@echo ... Continue with %QUARTUS_VERSION% ...

@echo -----------------------------------------

@if not defined QUADIR (
  @set QUADIR=C:/intelFPGAlite
)

@REM # check Intel path
:QUARTUS_PATH
@if exist %QUADIR% (
  @echo Use Quartus installation from '%QUADIR%'
  @GOTO START_CONFIG
)
@if not exist %QUADIR% (
  @echo '%QUADIR%' did not exists.
  @GOTO SPECIFY_QUARTUS_DIR
)

:START_CONFIG
@REM # -----------------
@REM # --- copy bash files
	@if exist %cmd_folder%quartus_create_project_batchmode.cmd 		( @copy %cmd_folder%quartus_create_project_batchmode.cmd %batchfile_path%quartus_create_project_batchmode.cmd)
	@if exist %cmd_folder%quartus_open_existing_project_guimode.cmd ( @copy %cmd_folder%quartus_open_existing_project_guimode.cmd %batchfile_path%quartus_open_existing_project_guimode.cmd)

@REM # --------------------
@echo -- Use Quartus Version: %QUARTUS_VERSION% --
@echo -----------------------------------------

@REM # -----------------
@REM # --- delete request if old project exits
@echo ----------------------check old project exists--------------------------
@set quartus_p_folder=%batchfile_path%quartus

@if exist %quartus_p_folder% ( @echo Old quartus project was found: Create project will delete older project!
  @goto  before_uinput
)  
@goto  after_uinput

:before_uinput
@set /p creatProject="Are you sure to continue? (y/N):"
@echo User Input: "%creatProject%"
@if not "%creatProject%"=="y" (GOTO EOF)

:after_uinput
@echo Start create project..."
@echo ----------------------- Create log folder ---------------------------
@REM log folder
@set log_folder=%batchfile_path%log
@echo %log_folder%
@if exist %log_folder% ( @del /S /Q %log_folder% )

@mkdir %log_folder%  
@echo --------------------------------------------------------------------
@echo ----------------------- Start Quartus scripts ----------------------
"%QUADIR%/%QUARTUS_VERSION%/nios2eds/Nios II Command Shell.bat" quartus_sh -t scripts/script_main.tcl --run_board_selection
@echo ------------------------ scripts finished --------------------------
@echo --------------------------------------------------------------------
@echo ----------------------- Design finished ----------------------------


@GOTO LAST_DESCR

:SPECIFY_QUARTUS_DIR
@set /p new_cmd=" Please specifiy you Intel installation folder: "
@set QUADIR=%new_cmd%
@GOTO QUARTUS_PATH

@REM ------------------------------------------------------------------------------
:LAST_DESCR
@if not exist %batchfile_path%design_basic_settings.cmd ( @copy %cmd_folder%design_basic_settings.cmd %batchfile_path%design_basic_settings.cmd)
@echo ---------------------------Minimal Setup----------------------------
@echo --- 1. Open "design_basic_settings.cmd" with text editor
@echo --- 1.1  Set Quartus Installation path, default:  @set QUADIR=C:/intelFPGA_lite
@echo --- 1.2  Set the Board Part you bought, example: @set PARTNUMBER=2
@echo ---       For available names see: ./board_files/TEIxxxx_devices.csv
@echo --- 1.3 Save "design_basic_settings.cmd"
@echo --- Create and open Quartus Project with batch files:
@echo --- 2. To create quartus project, execute: ./quartus_create_project_batchmode.cmd
@echo --- Open existing Quartus Project with batch files:
@echo --- 3. To open existing quartus project, execute: ./quartus_open_existing_project_guimode.cmd
@echo --- Use Trenz Electronic Wiki for more information:
@echo ---   https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices
@echo --------------------------------------------------------------------
@GOTO EOF
@REM ------------------------------------------------------------------------------
:ERROR
@echo -------------------------- Error occurs ----------------------------
@echo --------------------------------------------------------------------
@PAUSE
@REM ------------------------------------------------------------------------------

:EOF
@echo ----------------------------- Finished -----------------------------
@echo --------------------------------------------------------------------