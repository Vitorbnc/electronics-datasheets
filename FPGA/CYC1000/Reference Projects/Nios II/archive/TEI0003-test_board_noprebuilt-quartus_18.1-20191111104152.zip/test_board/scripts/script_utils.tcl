# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25  | $Author: Thomas Dück
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {
	set ::TE::LOG_PATH [pwd]/log ;#need for ::TE::UTILS::write_log_file
	set ::TE::cntscriptinfo 0
	set ::TE::cntscriptwarning 0
	set ::TE::cntscriptcriticalwarning 0
	set ::TE::cntscripterror 0
	
	set ::TE::cntprebinfo 0
	set ::TE::cntprebwarning 0
	set ::TE::cntprebcriticalwarning 0
	set ::TE::cntpreberror 0
	
  namespace eval UTILS {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # report functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
    #--report: 
	proc report {RESULT COMMAND ID} {
		::TE::UTILS::te_msg -type Info -id $ID -msg "Command results on: $COMMAND:\n"
		set data [split $RESULT "\n"]
		foreach line $data {
			if {[regexp -nocase {Error: (.*)} $line matched linetmp1] || [regexp {Error (\((.*)\): (.*))} $line matched linetmp1]} {				
				::TE::UTILS::te_msg -type Error -msg "$linetmp1"				
				return 1
			} elseif {[regexp -nocase {Warning: (.*)} $line matched linetmp2] || [regexp {Warning (\((.*)\): (.*))} $line matched linetmp2]} {			
				::TE::UTILS::te_msg -type Warning -msg "$linetmp2"
			} elseif {[regexp -nocase {Critical Warning: (.*)} $line matched linetmp3] || [regexp {Critical Warning (\((.*)\): (.*))} $line matched linetmp3]} {			
				::TE::UTILS::te_msg -type Critical_Warning -msg "$linetmp3"
			} else {
				if {[regexp -nocase {Info: (.*)} $line matched linetmp4] || [regexp {Info (\((.*)\): (.*))} $line matched linetmp4]} {

					::TE::UTILS::te_msg -type Info -msg "$linetmp4"
				} else {::TE::UTILS::te_msg -msg "$line"}	
			}
		}
		return 0
	} 
	
	#--------------------------------
    #--reprot prebuilt_hw_summary.csv 
	proc report_prebuilt_hw_summary {} {
		set date "[ clock format [clock seconds] -format "%Y-%m-%d_%H:%M:%S"]"
		set status "Error"
		set counts [split [extract_rpt_files] ","]
		if {[lindex $counts 3] == 0 && ${::TE::cntpreberror} == 0} {set status "Ok"}
      
		set prebuilt_file ${::TE::PREBUILT_PATH}/hardware_summary.csv
		if {![file exists ${prebuilt_file}]} {
			set fp_w [open ${prebuilt_file} "w"]
			puts $fp_w [format "%-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s," "Date" "Status" "ProjName" "BoardDefShortName" "BoardDefName" "CompInfo" "CompWarnings" "CompCritWarnings" "CompError" "PrebInfo" "PrebWarnings" "PrebCritWarnings" "PrebError" "Prebtime/s"]
			close $fp_w
		}
		
		set report "[format "%-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s, %-40s," "$date" "$status" "${::TE::QPROJ_NAME}" "${::TE::SHORTNAME}" "${::TE::PRODID}"  "[lindex $counts 0]" "[lindex $counts 1]" "[lindex $counts 2]" "[lindex $counts 3]" "${::TE::cntprebinfo}" "${::TE::cntprebwarning}" "${::TE::cntprebcriticalwarning}" "${::TE::cntpreberror}" "${::TE::prebtime}"]"
      
		set fp_a [open ${prebuilt_file} "a"]
		puts $fp_a $report
		close $fp_a		
	}
	
	#--------------------------------
    #--extract_rpt_files: 
    proc extract_rpt_files {} {
		set cntinfo 0
		set cntwarning 0
		set cntcriticalwarning 0
		set cnterror 0
		
		set rpt_files [glob -directory ${::TE::QPROJ_PATH}/output_files *.rpt]
   
		foreach rpt $rpt_files {
			set messages false
			set fp_r [open ${rpt} "r"]
			set file_data [read $fp_r]
			set data [split $file_data "\n"]
			close $fp_r
		
			if {![regexp {(.*) report for} [lindex $data 0] matched rpt_name]} {
				::TE::UTILS::te_msg -type Critical_Warning -id TE_UTILS-27 -msg "File: $rpt. Report name not found."
			} else {	
				foreach line $data {
					if {[string match -nocase "\; $rpt_name Messages \;" $line]} {
						set messages true
					}
				
					if {$messages} {
						if {[regexp {Info } $line matched]} {
							incr cntinfo
						}
						if {[regexp {Warning } $line matched] && ![regexp {Critical Warning } $line matched]} {
							incr cntwarning
						}
						if {[regexp {Critical Warning } $line matched]} {
							incr cntcriticalwarning
						}
						if {[regexp {Error } $line matched]} {
							incr cnterror
						}
					}
				}
			}						
		}
		return "$cntinfo,$cntwarning,$cntcriticalwarning,$cnterror"
    }   

	#--------------------------------
    #--write output to log file quartus.log: 
	proc write_log_file {DATA} {		
		set log_file "${::TE::LOG_PATH}/quartus.log"		
		set fp_a [open ${log_file} a]
		puts $fp_a "$DATA"
		close $fp_a
	}

  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished report functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # modify tcl files functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
 	#--------------------------------
    #--modify tcl:  
	proc modify_files {} {			
		::TE::UTILS::te_msg -type Info -id TE_UTILS-30 -msg "	Modify files. Please wait ..."
		set data "NA"
		foreach modlist $::TE::MOD_LIST {
			::TE::UTILS::te_msg -type Info -msg "	>> $modlist"			
			set line_index -1
			set id [lindex $modlist 0]
			set line_check [lindex $modlist 1]
			set modify [list]
			for {set i 2} {$i < [llength $modlist]} {incr i} {
				lappend modify [lindex $modlist $i]
			}
			
			foreach line $data {
				incr line_index
				switch $id {
					"read" {
						set fpr [open "${::TE::QPROJ_PATH}/[lindex $modlist 1]" r]
						set filedata [read $fpr]
						close $fpr
						set data [split $filedata "\n"]
						
						break
					}
					"write" {
						set fpw [open "${::TE::QPROJ_PATH}/[lindex $modlist 1]" w]
						foreach line $data {
							puts $fpw $line
						}
						close $fpw
						break
					}
					"0" {
						if {[string match $line_check $line] && ![string match *#TE_MOD#* $line]} {
							if {$modify ne "NA"} {
								foreach mod $modify {
									set data [lreplace $data[set data {}] $line_index $line_index "# #TE_MOD# $line\n# #TE_MOD#_Add next line\n$mod"]	
								}
							} else {
								set data [lreplace $data[set data {}] $line_index $line_index "# #TE_MOD# $line"]
							}
						}
					}
					"1" {
						if {[string match $line_check $line] && ![string match *#TE_MOD#* $line]} {
							foreach mod $modify {
								set data [linsert $data[set data {}] [expr $line_index-1] "# #TE_MOD#_Add next line\n$mod"]
							}
						}
					}
					"2" {
						if {[string match $line_check $line] && ![string match *#TE_MOD#* $line]} {
							set i 0
							foreach mod $modify {
								incr i
								set data [linsert $data[set data {}] [expr $line_index+$i]  "# #TE_MOD#_Add next line\n$mod"]
							}
						}
					}
					"3" {
						foreach mod $modify {
							if {[string match "set_instance_parameter_value $line_check {$mod}*" $line]} {
								set data [lreplace $data[set data {}] $line_index $line_index "# #TE_MOD# $line"]
							}					
						}
					}
					"4" {
						if {[string match "add_instance $line_check *" $line] && ![string match *#TE_MOD#* $line]} {
							set i 0
							foreach mod $modify {
								incr i
								set data [linsert $data[set data {}] [expr $line_index+$i]  "# #TE_MOD#_Add next line\n$mod"]
							}
						}
					}
					"5" {
						if {[string match "$line_check" $line] && ![string match *#TE_MOD#* $line]} {
							foreach mod $modify {
								regsub "$line_check" $line "$mod" line
								set data [lreplace $data[set data {}] $line_index $line_index "# #TE_MOD#_Replaced string next line \"$line_check\" -> \"$mod\"\n$line"]
							}
						}
					}
					"tcl_cmd" {
						catch $line_check result
					}
					default {::TE::UTILS::te_msg -type error -id TE_UTILS-29 -msg "(::TE::UTILS::modify_tcl) unrecognised option: ID: $id, line_check: $line_check, modify: $modify"}
				}			
			}
		}	
		::TE::UTILS::te_msg -type Info -id TE_UTILS-31 -msg "	Modify files -> done"
	}
  
 # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished modify tcl files functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # Clean functions 
  # -----------------------------------------------------------------------------------------------------------------------------------------
	
	#--------------------------------
    #--clean_all:  
	proc clean_all {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-4 -msg "	Clean all (project, software, log and prebuilt folder)"
		::TE::UTILS::clean_project
		::TE::UTILS::clean_software
		::TE::UTILS::clean_prebuilt
		::TE::UTILS::te_msg -type Info -id TE_UTILS-5 -msg "	Clean all -> finished"
	}
	
	#--------------------------------
    #--clean_project:  
    proc clean_project {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-6 -msg "	Clean project workspace"
		if {[file exist ${::TE::QPROJ_PATH}]} {
			if {[catch {file delete -force ${::TE::QPROJ_PATH}} result]} {
				::TE::UTILS::te_msg -type Error -id TE_UTILS-7 -msg "Error on ::TE::UTILS::clean_project:\n$result"
				return -code error
			} else {
				::TE::UTILS::te_msg -type Info -id TE_UTILS-8 -msg "	${::TE::QPROJ_PATH} deleted."
			} 
		} else {
			::TE::UTILS::te_msg -type Info -id TE_UTILS-9 -msg "	${::TE::QPROJ_PATH} doesn't exist."
		}
    }
	
	#--------------------------------
    #--clean_software:  
    proc clean_software {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-10 -msg "	Clean software workspace"
		if {[file exist ${::TE::SDK_PATH}]} {
			if {[catch {file delete -force ${::TE::SDK_PATH}} result]} {
				::TE::UTILS::te_msg -type Error -id TE_UTILS-11 -msg "Error on ::TE::UTILS::clean_software:\n$result"
				return -code error
			} else {
				::TE::UTILS::te_msg -type Info -id TE_UTILS-12 -msg "	${::TE::SDK_PATH} deleted."
			}
		} else {
			::TE::UTILS::te_msg -type Info -id TE_UTILS-13 -msg "	${::TE::SDK_PATH} doesn't exist."
		}
    }	
	
	#--------------------------------
    #--clean_source_files:  
    proc clean_source_files {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-18 -msg "	Clean source_files folder"
		if {[file exist ${::TE::SOURCE_PATH}] && [glob -nocomplain -directory ${::TE::SOURCE_PATH} *] != ""} {
			foreach dir [glob -tail -nocomplain -directory ${::TE::SOURCE_PATH} *] {
				if {[catch {file delete -force ${::TE::SOURCE_PATH}/${dir}} result]} {
					::TE::UTILS::te_msg -type Error -id TE_UTILS-19 -msg "Error on ::TE::UTILS::clean_source_files -> ${dir}:\n$result"
					return -code error
				} else {
					::TE::UTILS::te_msg -type Info -id TE_UTILS-20 -msg "	${::TE::SOURCE_PATH}/${dir} deleted."
				}
			}
		} else {
			::TE::UTILS::te_msg -type Info -id TE_UTILS-21 -msg "	${::TE::SOURCE_PATH} is already empty."
		}
	}
	
	#--------------------------------
    #--clean prebuilt files:  
    proc clean_prebuilt {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-22 -msg "	Clean prebuilt folder"
		if {[file exists ${::TE::PREBUILT_PATH}] && [glob -nocomplain -directory ${::TE::PREBUILT_PATH} *] != ""} {
			foreach dir [glob -tail -nocomplain -directory ${::TE::PREBUILT_PATH} *] {
				if {[catch {file delete -force ${::TE::PREBUILT_PATH}/${dir}} result]} {
					::TE::UTILS::te_msg -type Error -id TE_UTILS-23 -msg "Error on ::TE::UTILS::clean_prebuilt -> ${dir}:\n$result"
					return -code error
				} else {
					::TE::UTILS::te_msg -type Info -id TE_UTILS-24 -msg "	${::TE::PREBUILT_PATH}/${dir} was deleted."
				}
			}
		} else {
			::TE::UTILS::te_msg -type Info -id TE_UTILS-25 -msg "	${::TE::PREBUILT_PATH} is already empty."
		}
	}
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished clean functions 
  # -----------------------------------------------------------------------------------------------------------------------------------------

  # -----------------------------------------------------------------------------------------------------------------------------------------
  # Additional functions 
  # -----------------------------------------------------------------------------------------------------------------------------------------
    #--------------------------------
    #--print_boardlist:  
    proc print_boardlist {} {
		foreach line $::TE::BOARD_DEFINITION {
			if {[string match -nocase *id* $line]} {
				::TE::UTILS::te_msg -msg [format "==========================================================================================================================================================="]
				::TE::UTILS::te_msg -msg [format "|%-3s|%-20s|%-20s|%-20s|%-15s|%-10s|%-12s|%-25s|%-10s|%-10s|" "[lindex $line 0]" "[lindex $line 1]" "[lindex $line 2]" "[lindex $line 3]" "[lindex $line 4]" "[lindex $line 5]" "[lindex $line 6]" "[lindex $line 7]" "[lindex $line 8]" "[lindex $line 9]"]
				::TE::UTILS::te_msg -msg [format "==========================================================================================================================================================="]
			} else {
				::TE::UTILS::te_msg -msg [format "|%-3s|%-20s|%-20s|%-20s|%-15s|%-10s|%-12s|%-25s|%-10s|%-10s|" "[lindex $line 0]" "[lindex $line 1]" "[lindex $line 2]" "[lindex $line 3]" "[lindex $line 4]" "[lindex $line 5]" "[lindex $line 6]" "[lindex $line 7]" "[lindex $line 8]" "[lindex $line 9]"]
				::TE::UTILS::te_msg -msg [format "-----------------------------------------------------------------------------------------------------------------------------------------------------------"]
			}			
		}
	}
	
	#--------------------------------
	#copy source files to project folder
	proc copy_source_files {} {
		::TE::UTILS::te_msg -type Info -id TE_UTILS-26 -msg "	Copy source files to project ..."
		
		foreach sourcefile [glob -nocomplain -directory $::TE::SOURCE_PATH/quartus *] {
			set command "file copy -force $sourcefile ${::TE::QPROJ_PATH}"
			if {[catch {eval $command} result]} {
				::TE::UTILS::te_msg -type error -id TE_UTILS-28 -msg "Error on $command: \n $result"
				return -code error 
			}
		}
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#post message + write to log file
	proc te_msg {args} {
		#ID: TE_DES, TE_EXP, TE_QUAR, TE_SDK, TE_INIT, TE_BDEF, TE_UTILS 
		#last ID number:
		#TE_MAIN	9		-> script_main.tcl
		#TE_DES		57		-> script_designs.tcl
		#TE_EXP		34		-> script_export.tcl
		#TE_QUART	36		-> script_quartus.tcl
		#TE_SDK		18		-> script_software.tcl
		#TE_INIT	12		-> script_settings.tcl
		#TE_BDEF	1		-> script_settings.tcl
		#TE_UTILS	31		-> script_utils.tcl				
		#TYPE: Info, WARNING, CRITICAL_WARNING, ERROR, STD
		#Example: ::TE::UTILS::te_msg -type Info -id "TE_UTILS-1" -msg "te_msg example"
		
		set TYPE "NA"
		set ID "NA"
		set MESSAGE "NA"
		set num [llength $args]
		for {set option 0} {$option < $num} {incr option} {
			switch [lindex $args $option] {
				"-type"				{set TYPE 		[lindex $args $option+1]; 	incr option;}	
				"-id"				{set ID 		[lindex $args $option+1]; 	incr option;}
				"-msg"		        {set MESSAGE 	[lindex $args $option+1]; 	incr option;}
				default             {::TE::UTILS::write_log_file "(::TE::UTILS::te_msg) unrecognised argument [lindex $args $option]."
									 post_message -type Error "(::TE::UTILS::te_msg) unrecognised argument [lindex $args $option].\nExpected arguments: te_msg \[options\] \[-msg \"<message>\"\]\n                  \
																							Options: \n                      \
																								-id \"<id>\" \n                      \
																								-type  {Info || Warning || Critical_Warning || Error}\n"
									}
			}
		}
		
		if {$TYPE ne "NA"} { # for better overview in log file
			switch -nocase $TYPE { 
				"info"				{set TYPE "Info"; 				incr ::TE::cntscriptinfo; 				incr ::TE::cntprebinfo}
				"warning"			{set TYPE "Warning"; 			incr ::TE::cntscriptwarning; 			incr ::TE::cntprebwarning}
				"critical_warning"	{set TYPE "Critical_Warning";	incr ::TE::cntscriptcriticalwarning;	incr ::TE::cntprebcriticalwarning}
				"error"				{set TYPE "Error";				incr ::TE::cntscripterror; 				incr ::TE::cntpreberror}
				default 			{post_message -type error "Invalid type $TYPE. Available types: Info || Warning || Critical_Warning || Error"; ::TE::UTILS::write_log_file "::TE::UTILS::te_msg invalid type $TYPE."}
			}
		}
		
		if {![string match -nocase "NA" $MESSAGE]} {	
			if {![string match -nocase "NA" $TYPE]} {
				if {![string match -nocase "NA" $ID]} {
					post_message -type $TYPE "\[$ID\] $MESSAGE"
					::TE::UTILS::write_log_file "$TYPE: \[$ID\] $MESSAGE"
				} else {
					post_message -type $TYPE "$MESSAGE"
					::TE::UTILS::write_log_file "$TYPE: $MESSAGE"
				}
			} else {
				if {![string match -nocase "NA" $ID]} {
					puts "\[$ID\] $MESSAGE"
					::TE::UTILS::write_log_file "\[$ID\] $MESSAGE"
				} else {
					puts "$MESSAGE"
					::TE::UTILS::write_log_file "$MESSAGE"
				}
			}
		} else {
			::TE::UTILS::write_log_file "::TE::UTILS::te_msg -id $ID -type $TYPE -msg $MESSAGE failed. No message available."
			return -code error "::TE::UTILS::te_msg -id $ID -type $TYPE -msg $Message failed. No message available.\nExpected arguments: te_msg \[options\] \[-msg \"<message>\"\]\n                  \
																		Options: \n                      \
																			-id \"<id>\" \n                      \
																			-type {Info || Warning || Critical_Warning || Error}\n"
		}
	}
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished additional functions 
  # -----------------------------------------------------------------------------------------------------------------------------------------
	
  }
  set log_file "${::TE::LOG_PATH}/quartus.log"
  if {![file exist $log_file]} {
	set fp [open ${log_file} w]
  } else {
	set fp [open ${log_file} a]
  }
  puts $fp  " -----------------------------------------------------------------------\n\
             Quartus $::quartus(version)\n\
             Start of session at: [clock format [clock seconds] -format "%a %b %d %Y %T"]\n\
             Current directory: [pwd]\n\
             Log file: ${::TE::LOG_PATH}/quartus.log\n\
             -----------------------------------------------------------------------\n"
  close $fp
			
  ::TE::UTILS::te_msg -type info -msg "(TE) Load Utilities script finished"
}


