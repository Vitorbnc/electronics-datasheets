# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25 | $Author: Dück, Thomas
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {

  # -----------------------------------------------------------------------------------------------------------------------------------------
  # TE variable declaration
  # -----------------------------------------------------------------------------------------------------------------------------------------

  variable QPROJ_NAME 
  variable QSYS_NAME
  variable ZIP_IGNORE_LIST [list]

  # project path
  variable BASEFOLDER 
  variable QPROJ_PATH   
  variable BOARDDEF_PATH
  variable SOURCE_PATH
  variable SDK_PATH
  variable LOG_PATH 	
  variable BACKUP_PATH
  variable SET_PATH
  
  # board files
  variable ID 		 	"NA"
  variable LAST_ID 	 	"NA"
  variable PRODID  	 	"NA"
  variable FAMILY 	 	"NA"
  variable DEVICE	 	"NA"
  variable SHORTNAME 	"NA"
  variable FLASHTYP 	"NA"
  variable FLASH_SIZE 	"NA"
  variable DDR_DEV		"NA"
  variable DDR_SIZE 	"NA"
  variable PCB_REV 		"NA"

  variable BOARD_DEFINITION
  
  variable MOD_LIST [list]
  
  # version
  variable SCRIPTVER		"18.1.00"
  variable BOARDDEF_CSV 	"1.0"
  variable ZIP_IGNORE_CSV	"1.0"
  variable MODLIST_CSV		"1.0"
  variable QVERSION			"18.1"

  # -----------------------------------
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished TE variables declaration
  # -----------------------------------------------------------------------------------------------------------------------------------------
    
  # -----------------------------------------------------------------------------------------------------------------------------------------
  namespace eval INIT {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # initial functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
    #--------------------------------	
    #--init_pathvar:  
    proc init_pathvar {} {
		set tmppath [pwd]
		if {[file tail [pwd]]=="quartus"} {
			cd ..
		}	
		# set path
		set ::TE::BASEFOLDER 		[pwd]
		set ::TE::QPROJ_PATH 		[pwd]/quartus
		set ::TE::BOARDDEF_PATH 	[pwd]/board_files
		set ::TE::PREBUILT_PATH 	[pwd]/prebuilt
		set ::TE::SOURCE_PATH 		[pwd]/source_files	  
		set ::TE::LOG_PATH 			[pwd]/log
		set ::TE::SDK_PATH 			[pwd]/software
		set ::TE::BACKUP_PATH		[pwd]/backup
		set ::TE::SET_PATH			[pwd]/settings
	  
		#set name
		set ::TE::QPROJ_NAME [file tail [pwd]]
	 
		cd $::TE::BASEFOLDER

	  	::TE::UTILS::te_msg -type info -id TE_INIT-1 -msg "Board Part definition:\n \
        ::TE::BASEFOLDER:       ${::TE::BASEFOLDER} \n \
        ::TE::QPROJ_PATH:       ${::TE::QPROJ_PATH} \n \
        ::TE::BOARDDEF_PATH:    ${::TE::BOARDDEF_PATH} \n \
		::TE::PREBUILT_PATH:    ${::TE::PREBUILT_PATH} \n \
        ::TE::SOURCE_PATH:      ${::TE::SOURCE_PATH} \n \
        ::TE::LOG_PATH:         ${::TE::LOG_PATH} \n \
        ::TE::SDK_PATH:         ${::TE::SDK_PATH} \n \
		::TE::BACKUP_PATH:      ${::TE::BACKUP_PATH} \n \
		::TE::SET_PATH:         ${::TE::SET_PATH} \n \
        ------"
    } 
	
	#--------------------------------
    #--get qsys name
	proc get_qsys_name {} {
		set ::TE::QSYS_NAME ""
		if {[glob -nocomplain ${::TE::QPROJ_PATH}/*.qsys] != ""} {
			set qsysdir [glob -tail -directory ${::TE::QPROJ_PATH} *.qsys]
			foreach filename $qsysdir {
				regsub ".qsys" $filename "" filename	
				#add qsys name to list
				lappend ::TE::QSYS_NAME "$filename"	
			}
		} elseif {[file exist ${::TE::SOURCE_PATH}/quartus/${::TE::QPROJ_NAME}.tcl]} {
			set fpr [open "${::TE::SOURCE_PATH}/quartus/${::TE::QPROJ_NAME}.tcl" r]
			set filedata [read $fpr]
			close $fpr			
			#search for *.qip file and *.qsys file in <project>.tcl
			set data [split $filedata "\n"]
			foreach line $data {
				if {[regexp -line {QIP_FILE (.*).qip} $line matched file] || [regexp -line {QSYS_FILE (.*).qsys} $line matched file]} {
					set filename [file tail $file]	
					#search for <qsys>.tcl
					if {[file exists ${::TE::SOURCE_PATH}/quartus/${filename}.tcl]} {
						#add qsys name to list
						lappend ::TE::QSYS_NAME "$filename"
					}				
				}	
			}
		}
	}
	
    #--------------------------------
    #--init_boardlist: 
    proc init_boardlist {} {
		set device_files ""
		set ::TE::BOARD_DEFINITION [list]
		if { [catch {set device_files [ glob ${::TE::BOARDDEF_PATH}/*_devices_mod.csv ] }] } {
			if { [catch {set device_files [ glob ${::TE::BOARDDEF_PATH}/*_devices.csv ] }] } {
				::TE::UTILS::te_msg -type error -id TE_INIT-2 -msg "No board part definition list found (::TE::INIT::init_boardlist - Path: ${::TE::BOARDDEF_PATH})."
				error "Error on ::TE::INIT::init_boardlist -> Path: ${::TE::BOARDDEF_PATH}"
			}	
		} else {
			::TE::UTILS::te_msg -type warning -id TE_INIT-3 -msg "Modified board part definition list found (File: ${device_files})."
		}
		if {$device_files ne ""} {
			#puts "Read board part definition list (File ${device_files})."
			set fp [open "${device_files}" r]
			set file_data [read $fp]
			close $fp

			set data [split $file_data "\n"]
			foreach line $data {
				#  check file version ignore comments and empty lines
				if {[string match *#* $line] != 1 && [string match *CSV_VERSION* $line] } {
					# in case somebody has save csv with other programm add comma can be add
					set linetmp [lindex $[split $line ","] 0]
					#remove spaces
					set linetmp [string map {" " ""} $linetmp]
					#remove tabs
					set linetmp [string map {"\t" ""} $linetmp]
					#check version
					set tmp [split $linetmp "="]
					if {[string match [lindex $tmp 1] ${::TE::BOARDDEF_CSV}] != 1} {
						::TE::UTILS::te_msg -type error -id TE_INIT-4 -msg "Wrong board part definition CSV version (${TE::BOARDDEF_PATH}/device_files.csv) get [lindex $tmp 1] expected ${TE::BOARDDEF_CSV}."
						return -code error 
					}
				} elseif {[string match *#* $line] != 1 && [string length $line] > 0} {
					#remove spaces
					# set line [string map {" " ""} $line]
					#remove tabs
					set line [string map {"\t" ""} $line]
					#split and append
					set tmp [split $line ","]
					for {set index 0 } {$index < [llength $tmp]} {incr index} {
						set tempvalue [lindex $tmp $index]
						if {[string match *\"* $tempvalue] == 1} {
							set tempvalue2 [split $tempvalue "\""]
							if { [llength $tempvalue2] > 2 } {
								set tempvalue [lindex $tempvalue2 1]
								set tmp [lreplace $tmp $index $index $tempvalue]
							}
						} else {
						#remove spaces
						set tempvalue [string map {" " ""} $tempvalue]
						set tmp [lreplace $tmp $index $index $tempvalue]
						}  
					}
					lappend ::TE::BOARD_DEFINITION $tmp
				}
			}
		}
    }
	
	#--------------------------------
	#--init_zip_ignore_list: 
	proc init_zip_ignore_list {} {
		set ::TE::ZIP_IGNORE_LIST [list]
		if {[file exists  ${TE::SET_PATH}/zip_ignore_list.csv]} { 
			::TE::UTILS::te_msg -type info -id TE_INIT-5 -msg "Read ZIP ignore list (File: ${TE::SET_PATH}/zip_ignore_list.csv)."
			set fp [open "${TE::SET_PATH}/zip_ignore_list.csv" r]
			set file_data [read $fp]
			close $fp
			set data [split $file_data "\n"]
			foreach line $data {
				#  check file version ignore comments and empty lines
				if {[string match *#* $line] != 1 && [string match *CSV_VERSION* $line] } {
					#remove spaces
					set line [string map {" " ""} $line]
					#remove tabs
					set line [string map {"\t" ""} $line]
					#check version
					set tmp [split $line "="]
					if {[string match [lindex $tmp 1] ${::TE::ZIP_IGNORE_CSV}] != 1} {
						::TE::UTILS::te_msg -type error -id TE_INIT-6 -msg "Wrong Zip ignore definition CSV Version (${::TE::SET_PATH}/zip_ignore_list.csv) get [lindex $tmp 1] expected ${::TE::ZIP_IGNORE_CSV}."
						return -code error 
					}
				} elseif {[string match *#* $line] != 1 && [string length $line] > 0} {
					#remove spaces
					set line [string map {" " ""} $line]
					#remove tabs
					set line [string map {"\t" ""} $line]
					#splitt and append
					set tmp [split $line ","]
					lappend ::TE::ZIP_IGNORE_LIST $tmp
				}
			}
		} else {
			::TE::UTILS::te_msg -type error -id TE_INIT-7 -msg "No Zip ignore list used."
		}
	}
	
	#--------------------------------
	#--init_board:  
    proc init_board {ID} {
		if {$ID ne "NA"} {
			set ::TE::ID            $ID
			set ::TE::PRODID 		[lindex ${::TE::BOARD_DEFINITION} $ID 1]
			set ::TE::FAMILY 		[lindex ${::TE::BOARD_DEFINITION} $ID 2]
			set ::TE::DEVICE 		[lindex ${::TE::BOARD_DEFINITION} $ID 3]
			set ::TE::SHORTNAME 	[lindex ${::TE::BOARD_DEFINITION} $ID 4]
			set ::TE::FLASHTYP		[lindex ${::TE::BOARD_DEFINITION} $ID 5]
			set ::TE::FLASH_SIZE	[lindex ${::TE::BOARD_DEFINITION} $ID 6]
			set ::TE::DDR_DEV		[lindex ${::TE::BOARD_DEFINITION} $ID 7]
			set ::TE::DDR_SIZE 		[lindex ${::TE::BOARD_DEFINITION} $ID 8]
			set ::TE::PCB_REV 		[lindex ${::TE::BOARD_DEFINITION} $ID 9]
		} else {		
			set ::TE::ID            $ID
			set ::TE::PRODID 		$ID
			set ::TE::FAMILY 		$ID
			set ::TE::DEVICE 		$ID
			set ::TE::SHORTNAME 	$ID
			set ::TE::FLASHTYP		$ID
			set ::TE::FLASH_SIZE	$ID
			set ::TE::DDR_DEV		$ID
			set ::TE::DDR_SIZE		$ID
			set ::TE::PCB_REV		$ID
			::TE::UTILS::te_msg -type warning -id TE_INIT-8 -msg "::TE::BDEF::init_board:  ID $ID not found in device_list.csv."
		}

		::TE::UTILS::te_msg -type info -id TE_INIT-9 -msg "Board Part definition:\n \
        ::TE::ID:           ${::TE::ID} \n \
        ::TE::PRODID:       ${::TE::PRODID} \n \
        ::TE::FAMILY:       ${::TE::FAMILY} \n \
        ::TE::DEVICE:       ${::TE::DEVICE} \n \
        ::TE::SHORTNAME:    ${::TE::SHORTNAME} \n \
        ::TE::FLASHTYP:     ${::TE::FLASHTYP} \n \
        ::TE::FLASH_SIZE:   ${::TE::FLASH_SIZE} \n \
		::TE::DDR_DEV:      ${::TE::DDR_DEV} \n \
        ::TE::DDR_SIZE:     ${::TE::DDR_SIZE} \n \
        ::TE::PCB_REV:      ${::TE::PCB_REV} \n \
        ------"
    }
	    
    #--------------------------------
    #--init_mod_list: 
	proc init_mod_list {} {
		if {[file exists  ${TE::SET_PATH}/mod_list.csv]} { 
			::TE::UTILS::te_msg -type info -id TE_INIT-10 -msg "Read qsys modify list (File: ${TE::SET_PATH}/mod_list.csv)."
			set fp [open "${TE::SET_PATH}/mod_list.csv" r]
			set file_data [read $fp]
			close $fp
			set data [split $file_data "\n"]
			foreach line $data {
				#ignore comments and empty lines
				if {[string match #* $line] != 1 && [string length $line] > 0} {
					#  check file version
					if {[string match *CSV_VERSION* $line] } {
						#remove tabs
						set line [string map {"\t" ""} $line]
						#check version
						set tmp [split $line "="]
						if {[string match [lindex $tmp 1] $::TE::MODLIST_CSV] != 1} {
							TE::UTILS::te_msg -type error -id TE_INIT-11 -msg "Wrong TCL Modify CSV Version (${TE::SET_PATH}/mod_list.csv) get [lindex $tmp 1] expected ${TE::MODLIST_CSV}."
							return -code error 
						}
					} else {
						#split line
						set temp [split $line ","]
						if {[llength $temp] <3} {
							TE::UTILS::te_msg -type warning -id TE_INIT-12 -msg "Not enough elements on line ($line). Line ignored."
						} else {
							#get line prodid +remove spaces and tabs
							#sort
								#table header
								#remove tabs
								set line [string map {"\t" ""} $line]
								set temp [split $line ","]
								lappend ::TE::MOD_LIST $temp
						}
					}
				}
			}
		}
    }
  
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished initial functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
   
  # -----------------------------------------------------------------------------------------------------------------------------------------
  }
  
  namespace eval BDEF {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # board part definition functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
	#--get_id: Name--> search name, POS: Table position ID....
	proc get_id {NAME} {
		set ::TE::LAST_ID 0
		foreach sublist $::TE::BOARD_DEFINITION {
			set data [split $sublist " "]
			foreach spdata $data {
				if { [string match -nocase $NAME $spdata] } {
				return [lindex $sublist 0]
				}
			}
			if {${::TE::LAST_ID} < [lindex $sublist 0] && [lindex $sublist 0] ne "ID"} {
			set ::TE::LAST_ID [lindex $sublist 0]
			}	
		}
		if {$NAME eq "LAST_ID"} {
			#return the the highest id from the list
			return ${::TE::LAST_ID}
		}
		#default
		::TE::UTILS::te_msg -type info -id TE_BDEF-1 -msg "ID not found for $NAME, return default: NA"
		return "NA"
	}     

  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished board part definition functions
  # ----------------------------------------------------------------------------------------------------------------------------------------- 
  }
  
  ::TE::UTILS::te_msg -type info -msg "(TE) Load Settings Script finished"
}