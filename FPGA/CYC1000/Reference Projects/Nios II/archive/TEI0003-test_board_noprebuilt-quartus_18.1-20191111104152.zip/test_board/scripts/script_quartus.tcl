# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25 | $Author: Dück, Thomas
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {
  namespace eval QUART {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  #quartus functions
  # -----------------------------------------------------------------------------------------------------------------------------------------	
	#--------------------------------
	# create qsys
	proc create_qsys {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-1 -msg "	Create qsys. Please wait ..."
		foreach qsysname ${::TE::QSYS_NAME} {
			set args [string map {" " "\\ "} "${::TE::DEVICE}|${::TE::FAMILY}|${::TE::DDR_DEV}"] 
			set command exec
			lappend command qsys-script
			lappend command --cmd=set\ ::args\ ${args}
			lappend command --script=${::TE::QPROJ_PATH}/${qsysname}.tcl	
			lappend command --search-path=${::TE::QPROJ_PATH}/ip/**/*,${::TE::SET_PATH}/*,$
			catch {eval $command} result
			if {[::TE::UTILS::report $result $command TE_QUART-2] == 1} {
				exit;
			}
		}
		
		::TE::UTILS::te_msg -type info -id TE_QUART-3 -msg "	Create qsys -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
	#generate qsys
	proc generate_qsys {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-4 -msg "	Generate qsys. Please wait ..."
		foreach qsysname ${::TE::QSYS_NAME} {
			set command exec
			lappend command qsys-generate
			lappend command ${::TE::QPROJ_PATH}/${qsysname}.qsys
			lappend command --synthesis=vhdl		
			lappend command -bsf
			lappend command --search-path=${::TE::QPROJ_PATH}/**/*,${::TE::SET_PATH}/*,$
			catch {eval $command} result
			if {[::TE::UTILS::report $result $command TE_QUART-5] == 1} {
				exit;
			}
		}
		::TE::UTILS::te_msg -type info -id TE_QUART-6 -msg "	Generate qsys -> done"		
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#regenerate IP Cores
	proc regenerate_ip {} {	
		::TE::UTILS::te_msg -type info -id TE_QUART-7 -msg "	Regenerate IP Cores. Please wait ..."
		set command exec
		lappend command mw-regenerate
		lappend command --project_directory=${::TE::QPROJ_PATH}
		catch {eval $command} result
		if {[::TE::UTILS::report $result $command TE_QUART-8] == 1} {			
			exit;
		}
		::TE::UTILS::te_msg -type info -id TE_QUART-9 -msg "	Regenerate IP Cores -> done"		
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#generate block symbol file
	proc generate_bsf {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-10 -msg "	Generate block symbol files. Please wait ..."
		set tmppath [pwd]			
		set dir [glob -directory ${::TE::QPROJ_PATH}/ *.vhd *.v vhdl/*.vhd verilog/*.v]
		foreach filedir $dir {
			set path $filedir
			regsub "[file tail $path]" $path "" path
			cd $path
			set command exec
			lappend command quartus_map
			lappend command --generate_symbol=$filedir
			catch {eval $command} result
			if {[::TE::UTILS::report $result $command TE_QUART-11] == 1} {			
				exit;
			}
		}
		cd $tmppath
		::TE::UTILS::te_msg -type info -id TE_QUART-12 -msg "	Generate block symbol files -> done"		
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#create empty project
	proc create_empty_project {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-13 -msg "	Create empty project. Please wait ..."
		set command "project_new -family \{${::TE::FAMILY}\} -part ${::TE::DEVICE} ${::TE::QPROJ_NAME}"
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-36
			cd ../
			exit;
		}
		::TE::UTILS::te_msg -type info -id TE_QUART-14 -msg "	Create empty project. Please wait ..."
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#execute <project>.tcl
	proc execute_project_tcl {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-15 -msg "	Execute ${::TE::QPROJ_NAME}.tcl. Please wait ..."
		set command exec
		lappend command quartus_sh
		lappend command -t
		lappend command ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}.tcl -ddr_dev ${::TE::DDR_DEV}
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-16
			exit;
		}	
		::TE::UTILS::te_msg -type info -id TE_QUART-17 -msg "	Execute ${::TE::QPROJ_NAME}.tcl -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}			

	#--------------------------------
	#compile project	
	proc compile_project {} {	
		::TE::UTILS::te_msg -type info -id TE_QUART-18 -msg "	Compile project. Please wait ..."
		set command exec
		lappend command quartus_sh
		lappend command --flow
		lappend command compile ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-19
		}	
		::TE::UTILS::te_msg -type info -id TE_QUART-20 -msg "	Compile project -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
		
		if {${::TE::FAMILY}=="Cyclone 10 LP"} {
			::TE::QUART::generate_jic_file
		}	
	}		

	#--------------------------------
	#open project
	proc start_quartus_gui {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-21 -msg "Open project. Please wait ..."
		set command exec
		lappend command quartus
		lappend command ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}.qpf
		::TE::UTILS::te_msg -type info -id TE_QUART-22 -msg "Project opened. Please change to GUI."
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-23
		}
		::TE::UTILS::te_msg -type info -id TE_QUART-24 -msg "Project closed."
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}

	#--------------------------------
	#generate *.jic file
	proc generate_jic_file {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-25 -msg "	Generate ${::TE::QPROJ_NAME}.jic file. Please wait ..."
		set command exec
		lappend command quartus_cpf
		lappend command -c
		lappend command ${::TE::QPROJ_PATH}/conversion_setup.cof
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-26
		}		
		::TE::UTILS::te_msg -type info -id TE_QUART-27 -msg "	Generate ${::TE::QPROJ_NAME}.jic file. -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#open quartus programmer
	proc start_programmer_gui {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-28 -msg "Start Programmer GUI. Please wait ..."
		set command qexec
		lappend command quartus_pgmw
		::TE::UTILS::te_msg -type info -id TE_QUART-29 -msg "Programmer GUI opened. Please change to GUI."
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_QUART-30
		}
		::TE::UTILS::te_msg -type info -id TE_QUART-31 -msg "Programmer GUI closed."
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}

	#--------------------------------
	#progamming ram memory
	proc program_sof {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-32-msg "Program device. Please wait ..."
		set command exec
		lappend command quartus_pgm
		lappend command -c Arrow-USB-Blaster
		lappend command -m jtag
		lappend command -o "p;${::TE::QPROJ_PATH}/output_files/${::TE::QPROJ_NAME}.sof"
		[catch {eval $command} result]
		::TE::UTILS::report $result $command TE_QUART-33
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}
					
	#--------------------------------
	#progamming flash memory
	proc program_pof {} {
		::TE::UTILS::te_msg -type info -id TE_QUART-34 -msg "Program device. Please wait ..."
		set command exec
		lappend command quartus_pgm
		lappend command -c Arrow-USB-Blaster
		lappend command -m jtag
		lappend command -o "bpv;${::TE::QPROJ_PATH}/output_files/${::TE::QPROJ_NAME}.pof"
		[catch {eval $command} result]
		::TE::UTILS::report $result $command TE_QUART-35
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}
	
  }  
  ::TE::UTILS::te_msg -type info -msg "(TE) Load Quartus script finished"
}