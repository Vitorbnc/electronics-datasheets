# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25 | $Author: Dück, Thomas
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------

namespace eval ::TE {
  namespace eval EXP {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # export functions
  # -----------------------------------------------------------------------------------------------------------------------------------------		
	#--------------------------------
	#create folder for source files
	proc create_source_folder {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-1 -msg "	Create new project source folder. Please wait ..."	
		if {![file exists ${::TE::SOURCE_PATH}/quartus]} {
				file mkdir ${::TE::SOURCE_PATH}/quartus
		}
		if {![file exists ${::TE::SOURCE_PATH}/software]} {
				file mkdir ${::TE::SOURCE_PATH}/software
		}		
		::TE::UTILS::te_msg -type info -id TE_EXP-2 -msg "	Create new project source folder -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#copy quartus project files to source_files/quartus
	proc export_project_files {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-3 -msg "	Copy quartus project files to source folder. Please wait ..."
		#search quartus design files
		set qdir [glob -tail -directory ${::TE::QPROJ_PATH}/ *.bdf *.sdc *.vhd *.v *.tcl ip *.cof]	
		set fpr [open "${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}.tcl" r]
		set filedata [read $fpr]
		close $fpr	
		set vhdl_dir ""
		set verilog_dir ""
		set data [split $filedata "\n"]
		foreach line $data {
			if {[regexp {VHDL_FILE (.*)} $line matched vhdl_dir]} {
				lappend qdir $vhdl_dir
			}	
			if {[regexp {VERILOG_FILE (.*)} $line matched verilog_dir]} {
				lappend qdir $verilog_dir
			}
		}
		#copy quartus design files
		foreach filedir $qdir {
			if {![string match -nocase *_bsp* $filedir]} {
				if {![file exist ${::TE::SOURCE_PATH}/quartus/$filedir] && [regexp {(.*)/(.*)} $filedir]} {
					set mkfiledir $filedir
					regexp {(\w+)\.(\w+)} $mkfiledir file
					regsub "$file" $mkfiledir "" mkfiledir
					file mkdir ${::TE::SOURCE_PATH}/quartus/$mkfiledir
				}
				file copy -force ${::TE::QPROJ_PATH}/$filedir ${::TE::SOURCE_PATH}/quartus/$filedir	
			}
		}
		::TE::UTILS::te_msg -type info -id TE_EXP-4 -msg "	Copy quartus project files to source folder -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
		
	#--------------------------------
	#copy software files to source_files/software
	proc export_software_files {} {
		if {[file exists ${::TE::SDK_PATH}] || [file exists ${::TE::QPROJ_PATH}/software]} {
			::TE::UTILS::te_msg -type info -id TE_EXP-5 -msg "	Copy software files to source folder. Please wait ..."
			#search software files
			set sdkdir [glob -tail -directory ${::TE::SDK_PATH}/ **/*.c **/*.h *.tcl ../quartus/software/**/*.c ../quartus/software/**/*.h ../quartus/software/*.tcl]
			#copy software files
			foreach filedir $sdkdir {
				if {![string match -nocase *_bsp* $filedir]} {
					set filename [file tail $filedir]
					if {[string match -nocase *.c* $filename] || [string match -nocase *.h* $filename] || [string match -nocase *bsp_settings.tcl* $filename]} {
						file copy -force ${::TE::SDK_PATH}/$filedir ${::TE::SOURCE_PATH}/software/$filename	
					} 
				}
			}
			::TE::UTILS::te_msg -type info -id TE_EXP-6 -msg "	Copy software files to source folder -> done"
		} else {::TE::UTILS::te_msg -type warning -id TE_EXP-7 -msg "Software project not found."}
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	
	#--------------------------------
	#generate <project>.tcl
	proc generate_tcl_proj {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-8 -msg "	Generate ${::TE::QPROJ_NAME}.tcl file. Please wait ..."
		::quartus::pjc_tcl_project_open ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
		set command ::quartus::pjc_tcl_project_generate_tcl_file    	
		lappend command ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
		lappend command overwrite	
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_EXP-9 -msg "Results on command: $command:\n $result"
		}
		::quartus::pjc_tcl_project_close
		if {[file tail [pwd]]=="quartus"} {
			cd ../
		}
		::TE::UTILS::te_msg -type info -id TE_EXP-10 -msg "	Generate ${::TE::QPROJ_NAME}.tcl file -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
	#generate <qsys>.tcl
	proc generate_tcl_qsys {} {
		foreach qsysname ${::TE::QSYS_NAME} {
			::TE::UTILS::te_msg -type info -id TE_EXP-11 -msg "	Generate $qsysname.tcl file. Please wait ..."
			set command exec
			lappend command qsys-generate
			lappend command ${::TE::QPROJ_PATH}/${qsysname}.qsys
			lappend command --export-qsys-script 
			[catch {eval $command} result]		
			::TE::UTILS::report $result $command TE_EXP-12	
			::TE::UTILS::te_msg -type info -id TE_EXP-13 -msg "	Generate $qsysname.tcl file -> done"
		}
		::TE::UTILS::te_msg -msg "------------------------------"
	}		
		
	#--------------------------------
	#generate prebuilt files (*.pof, *.jic)
	proc generate_prebuilt_files {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-18 -msg "	Generate prebuilt files. Please wait ..."		
		
		if {[catch {eval ::TE::UTILS::clean_prebuilt} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-19 -msg "Error on ::TE::UTILS::clean_prebuilt:\n$result"}
		
		#set global variables to correct device variant from device_list
		set list ""
		set ::TE::QPROJ_PATH ${::TE::BASEFOLDER}/tmp/quartus
		set ::TE::SDK_PATH ${::TE::BASEFOLDER}/tmp/software
		
		foreach line ${::TE::BOARD_DEFINITION} {
			set prebstarttime [clock seconds]
			set ::TE::cntprebinfo 0
			set ::TE::cntprebwarning 0
			set ::TE::cntprebcriticalwarning 0
			set ::TE::cntpreberror 0		
			
			file mkdir tmp
			cd tmp
			
			if {![string match *[lindex $line 4]* $list] && ![string match *SHORTNAME* $line]} {			
				if {[catch {eval ::TE::INIT::init_board [lindex $line 0]} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-22 -msg "$result"}
				lappend list ${::TE::SHORTNAME}
				
				#create and compile project and software
				if {[catch {eval ::TE::DES::run_build_project 0} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-23 -msg "Error on ::TE::DES::run_build_project 0:\n$result"}

				#create prebuilt subfolders if not exist
				if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files]} {
					file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files
				}
				if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware]} {
					file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware
				}
				if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software]} {
					file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software
				}				

				#copy generated prebuilt files to prebuilt subfolders
				foreach preb_source [glob -directory ${::TE::QPROJ_PATH}/output_files/ *.pof *.jic] {	
					regexp {(\w+)\.(\w+)} [file tail $preb_source] matched name type
					set new_name ${name}-${::TE::SHORTNAME}.${type}
					if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/${new_name}]} {	
						if {[catch {file copy -force [glob  ${::TE::QPROJ_PATH}/output_files/${matched}] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-24 -msg "$result"}
						if {[catch {file rename ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${matched} ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${new_name}} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-25 -msg "$result"}
					} else {post_message -type warning "File ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${new_name} already exist."}
				}
				if {[catch {file copy -force [glob -directory  ${::TE::QPROJ_PATH} *.sopcinfo] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-26 -msg "$result"}
				if {[catch {file copy -force [glob -directory  ${::TE::SDK_PATH} /**/*.elf] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-27 -msg "$result"}
				
				set prebstoptime [clock seconds]
				set ::TE::prebtime [expr ${prebstoptime} -${prebstarttime}] 
				if {[catch {eval ::TE::UTILS::report_prebuilt_hw_summary} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-28 -msg "Error on ::TE::UTILS::report_prebuilt_hw_summary:\n$result"}
			}	
			
			cd ${::TE::BASEFOLDER}
			file delete -force tmp			
		}
		
		set ::TE::QPROJ_PATH ${::TE::BASEFOLDER}/quartus
		set ::TE::SDK_PATH ${::TE::BASEFOLDER}/software

		::TE::UTILS::te_msg -type info -id TE_EXP-29 -msg "	Export prebuilt files -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
    #--zip_project: 
	proc zip_project {ZIPNAME EXCLUDELIST} {
		::TE::UTILS::te_msg -type info -id TE_EXP-30 -msg "	Zip Project. Please wait ..."
		#remove old backup project copy
		set sourcepath [string trim $TE::QPROJ_PATH "quartus"]
		set destinationpath ${TE::BACKUP_PATH}/${TE::QPROJ_NAME}
		if {[file exists ${destinationpath}]} { 
			file delete -force ${destinationpath}  
		}
		#create new destination folder
		file mkdir ${destinationpath}
		
		#get all files
		set filelist [ glob ${sourcepath}*]
		#remove backup folder
		set findex [lsearch $filelist *backup]
		set filelist [lreplace $filelist[set filelist {}] $findex $findex]
      
		foreach el $filelist {
			file copy -force ${el} ${destinationpath}
		}

		foreach el $EXCLUDELIST {
			set find ""
			if {[catch {set find [glob -join -dir $destinationpath $el]}] && [catch {set find [glob -type hidden -join -dir $destinationpath $el]}]} {
				::TE::UTILS::te_msg -type info -id TE_EXP-31 -msg "$el doesn't exist."
			} else {
				::TE::UTILS::te_msg -type info -id TE_EXP-32 -msg "Excluded from backup:$find"
				file delete -force $find
			}
		}
				
		#zip project	
		set command exec
		if {[file exists $::quartus(binpath)7z]} {
			lappend command 7z
			lappend command a
			lappend command -tzip 
			lappend command -o${::TE::BACKUP_PATH}
			lappend command "${ZIPNAME}.zip"
			lappend command ${TE::BACKUP_PATH}/${TE::QPROJ_NAME}
			lappend command -r		
		} else {
			lappend command zip
			lappend command -r
			lappend command ${ZIPNAME}.zip
			lappend command ${TE::QPROJ_NAME} 
	
		}
				
		cd ${::TE::BACKUP_PATH}
		catch {eval $command} result
		::TE::UTILS::te_msg -type info -id TE_EXP-33 -msg "Result of command $command:\n$result" 
		cd ${::TE::BASEFOLDER}
		
		#remove project copy
		if {[file exists ${destinationpath}]} { 
			file delete -force ${destinationpath}
		}

		::TE::UTILS::te_msg -type info -id TE_EXP-34 -msg "	Zip Project -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
    }
	
  #-----------------------------------------------------------------------------------------------------------------------------------------
  # finished export functions
  # -----------------------------------------------------------------------------------------------------------------------------------------	
  }
  ::TE::UTILS::te_msg -type info -msg "(TE) Load export script finished"
}


