# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25  | $Author: Thomas Dück
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {

  namespace eval SDK {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # sdk functions
  # -----------------------------------------------------------------------------------------------------------------------------------------		
	#--------------------------------
    #--create software files
	proc create_software_files {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-1 -msg "	Create software files. Please wait ..."
		set command exec
		lappend command nios2-swexample-create
		lappend command --sopc-file=${::TE::QPROJ_PATH}/${::TE::QSYS_NAME}.sopcinfo
		lappend command --type=blank_project
		lappend command --cpu-name=nios2
		lappend command --elf-name=${::TE::QPROJ_NAME}.elf
		lappend command --app-dir=${::TE::SDK_PATH}/${::TE::QPROJ_NAME}
		lappend command --bsp-dir=${::TE::SDK_PATH}/${::TE::QPROJ_NAME}_bsp
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_SDK-2 -msg  "Error on command: $command" 
			::TE::UTILS::report $result  $command TE_SDK-3
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-4 -msg "	Create software files -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}

	#--------------------------------
    #--create bsp	
	proc create_this_bsp {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-5 -msg "	Create bsp. Please wait ..."
		set command exec
		lappend command nios2-bsp-create-settings
		lappend command --sopc ${::TE::QPROJ_PATH}/${::TE::QSYS_NAME}.sopcinfo
		lappend command --type "hal"
		lappend command --settings "${::TE::SDK_PATH}/${::TE::QPROJ_NAME}_bsp/settings.bsp"
		lappend command --bsp-dir ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}_bsp
		lappend command --script $::quartus(quartus_rootpath)../nios2eds/sdk2/bin/bsp-set-defaults.tcl
		lappend command --script ${::TE::SDK_PATH}/bsp_settings.tcl
		lappend command --librarian-path ${::TE::QPROJ_PATH}/ip_components/**/*,$
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_SDK-6 -msg "Error on command: $command" 
			::TE::UTILS::report $result  $command TE_SDK-7
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-8 -msg "	Create bsp -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}

	#--------------------------------
    #--create app	
	proc create_this_app {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-9 -msg "	Create app. Please wait ..."
		set command exec
		lappend command nios2-app-generate-makefile
		lappend command --bsp-dir ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}_bsp
		lappend command --app-dir ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}
		lappend command --elf-name ${::TE::QPROJ_NAME}.elf
		lappend command --set QUARTUS_PROJECT_DIR ${::TE::QPROJ_PATH}
		lappend command --set OBJDUMP_INCLUDE_SOURCE 1
		set dir [glob -directory ${::TE::SOURCE_PATH} /software/*.c /software/*.h]	
		foreach filedir $dir {
			if {![string match -nocase *_bsp* $filedir]} {
				file copy -force $filedir ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}
				set filename [file tail $filedir]
				lappend command --src-files $filename			
			}			
		}	
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_SDK-10 -msg "Error on command: $command" 
			::TE::UTILS::report $result  $command TE_SDK-11
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-12 -msg "	Create app -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}

	
	#--------------------------------
    #--build software project
	proc app_make {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-13 -msg "	Make all - software. Please wait ..."
		set command exec
		lappend command make
		lappend command --directory ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result  $command TE_SDK-14
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-15 -msg "	Make all - software -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
    #--generate *.hex from *.elf
	proc generate_hex_file {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-16 -msg "	Generate hex file. Please wait ..."
		set command exec
		lappend command make mem_init_generate
		lappend command --directory ${::TE::SDK_PATH}/${::TE::QPROJ_NAME}
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result  $command TE_SDK-17
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-18 -msg "	Generate hex file -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished sdk functions
  # -----------------------------------------------------------------------------------------------------------------------------------------	
  }
  ::TE::UTILS::te_msg -type Info -msg "(TE) Load sdk script finished"
}
