# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Holzweg 19A             *
# --   *   32257 Bünde             *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25| $Author: Dück, Thomas
# -- - initial release 
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {
  namespace eval DES {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  #cmd functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
	#select board gui
	proc run_board_selection {} {
		::TE::UTILS::te_msg -msg "\nPlease enter the correct ID number from the table below:"
		TE::UTILS::print_boardlist
		::TE::UTILS::te_msg -msg "ID: "
		gets stdin id
		
		foreach line ${::TE::BOARD_DEFINITION} {
			if {![string match *ID* $line]} {
				lappend valid "[lindex $line 0]"
			}	
		}
		
		while {![regexp -all "$id" $valid] || $id == ""} {
			post_message -type error "Invalid input! ID \"$id\" doesn't exist!"
			::TE::UTILS::te_msg -msg "Please choose the correct ID number from the table above."
			::TE::UTILS::te_msg -msg "ID:"
			gets stdin id
		}
		
		if {[catch {::TE::DES::run_project $id 1 0 3} result]} {::TE::UTILS::te_msg -type error -id TE_DES-1 -msg "Script (::TE::DES::run_project) failed: $result."; return -code error}
	}	

	#--------------------------------
    #--run_project: quartus project
    proc run_project {BOARD RUN GUI CLEAN} {
		::TE::UTILS::te_msg -type info -id TE_DES-2 -msg "Run TE::INIT::run_project $BOARD $RUN $GUI $CLEAN"

		switch $CLEAN {
			0 {}
			1 { # clean all -> project folder
				if {[catch {TE::UTILS::clean_project} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-2 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-3 -msg "Script (TE::UTILS::clean_project) failed: $result."; 	return -code error}
			}
			2 { # clean all -> software folder
				if {[catch {TE::UTILS::clean_software} result]} {::TE::UTILS::te_msg -type error -id TE_DES-4 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-5 -msg "Script (TE::UTILS::clean_software) failed: $result."; 	return -code error}
			}
			3 { # clean all -> project and software folder
				if {[catch {TE::UTILS::clean_project} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-6 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-7 -msg "Script (TE::UTILS::clean_project) failed: $result."; 	return -code error}
				if {[catch {TE::UTILS::clean_software} result]} {::TE::UTILS::te_msg -type error -id TE_DES-8 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-9 -msg "Script (TE::UTILS::clean_software) failed: $result."; 	return -code error}
			}
			4 { # clean all -> project, software, prebuilt folder
				if {[catch {TE::UTILS::clean_all} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-10 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-11 -msg "Script (TE::UTILS::clean_all) failed: $result."; 	return -code error}
			}
			default {::TE::UTILS::te_msg -type error -id TE_DES-12 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-13 -msg "Error: Design clean option $CLEAN not available, use [show_help]"; return -code error}
		}
	  
		if {$RUN > 0 } {
			if {[catch {::TE::INIT::init_board [::TE::BDEF::get_id $BOARD]} result]} {::TE::UTILS::te_msg -type error -id TE_DES-14 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-15 -msg "Script (TE::INIT::init_board) failed: $result."; return -code error}
		}
	  
		switch $RUN {
			-1 {::TE::UTILS::te_msg -type info -id TE_DES-16 -msg "No mode selected ..."}
			 0 {::TE::DES::start_existing_project $GUI}
			 1 {::TE::DES::run_build_project $GUI}
			 2 {}
			 3 {::TE::DES::export_project_preb}
			default {::TE::UTILS::te_msg -type error -id TE_DES-17 -msg "Error Initialization..."; ::TE::UTILS::te_msg -type error -id TE_DES-18 -msg "Error: Design run option not available, use [show_help]"; return -code error}
		}
		::TE::UTILS::te_msg -type info -id TE_DES-19 -msg "Run project finished without Error.\n"
    }	
	
	#--------------------------------
    #--start_existing_project: 
    proc start_existing_project {GUI} {
		if {[file exists ${::TE::QPROJ_PATH}]} {
			if {[file exists ${::TE::QPROJ_PATH}/${TE::QPROJ_NAME}.qpf]} {
				if {$GUI >= 1} { 
					if {[catch {::TE::QUART::start_quartus_gui} result]} {::TE::UTILS::te_msg -type error -id TE_DES-20 -msg "Script (::TE::QUART::start_quartus_gui) failed: $result."; return -code error}
				}
			} else {
				::TE::UTILS::te_msg -type error -id TE_DES-21 -msg "Error: ${::TE::QPROJ_NAME}.qpf not found in ${::TE::QPROJ_PATH}"
				return -code error
			}
		} else {
			::TE::UTILS::te_msg -type error -id TE_DES-22 -msg "Error: ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}.qpf not found"
			return -code error 
		}	
    }
	
	#--------------------------------
    #--generate backup from project: 
    proc backup_project {BACKUP NAME} {
		# backup filename
		if {$NAME ne "NA"} {
			set zipname $NAME 
		} else {
			#generate file name
			set systemTime [clock seconds]
			set date [clock format $systemTime -format %Y%m%d%H%M%S]
			foreach line ${::TE::BOARD_DEFINITION} {
				if {![string match *PRODID* $line]} {			
					set ::TE::PRODID 	[lindex $line 1]
					regexp {(\w+)\-(\w+)} ${::TE::PRODID} matched board
				}
			}
			set zipname "${board}-${::TE::QPROJ_NAME}-quartus_${::TE::QVERSION}-${date}"
			set zipname_nopreb "${board}-${::TE::QPROJ_NAME}_noprebuilt-quartus_${::TE::QVERSION}-${date}"
		}
		
		# prepare exludelist from zip_ignore_list
		if {[llength $TE::ZIP_IGNORE_LIST] > 0} {
          set excludelist []
          foreach entry $TE::ZIP_IGNORE_LIST {
            if {[lindex $entry 0]==0} {
              #only id0 objects
              lappend excludelist [lindex $entry 1]
            } elseif {[lindex $entry 0]==1} {
              #only id1 objects
              set find []
              catch {set find [glob -join -dir $TE::BASEFOLDER [lindex $entry 1]]}
              foreach el $find {
                set sl_start [expr [string length $TE::BASEFOLDER]+1]
                set sl_stop [string length $el] 
                lappend excludelist [string range $el $sl_start $sl_stop]
              }
            }
          }
        }

		switch $BACKUP {
			 0 {::TE::EXP::zip_project $zipname $excludelist}
			 1 {lappend excludelist "prebuilt"; ::TE::EXP::zip_project $zipname_nopreb $excludelist}
			 2 {::TE::EXP::zip_project $zipname "NA"}
			 3 {if {[catch {eval ::TE::DES::generate_source_files} result]} {::TE::UTILS::te_msg -type error -id TE_DES-53 -msg "$result"}}
			default {::TE::UTILS::te_msg -type error -id TE_DES-23 -msg "Error Initialization...";  ::TE::UTILS::te_msg -type error -id TE_DES-24 -msg "Error: Design backup option not available, use [show_help]"; return -code error}
		}
    }
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished cmd functions
  # -----------------------------------------------------------------------------------------------------------------------------------------

  # -----------------------------------------------------------------------------------------------------------------------------------------
  # project design functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
	#build project + compile project
	proc run_build_project {GUI} {
		::TE::UTILS::te_msg -msg "\n-----------------------------------------------------------------------"	
		if {![file exist  ${::TE::QPROJ_PATH}]} {
			file mkdir  ${::TE::QPROJ_PATH}
		}
		cd ./quartus 
		::TE::UTILS::te_msg -type info -id TE_DES-25 -msg "Run build project (all). Please wait ..."
		if {[catch {eval ::TE::QUART::create_empty_project} result]} {::TE::UTILS::te_msg -type error -id TE_DES-26 -msg "$result"}
		if {![file exist ${::TE::SOURCE_PATH}/quartus/${::TE::QPROJ_NAME}.tcl]} {
			::TE::UTILS::te_msg -type warning -id TE_DES-27 -msg "${::TE::SOURCE_PATH}/quartus folder is empty."
			return 0;
		}		
		if {[catch {eval ::TE::UTILS::copy_source_files} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-28 -msg "$result"}
		if {[catch {eval ::TE::UTILS::modify_files} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-46 -msg "$result"}
		if {$GUI == 1} {start_existing_project $GUI}
		if {[catch {eval ::TE::QUART::create_qsys} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-29 -msg "$result"}
		if {[catch {eval ::TE::QUART::generate_qsys} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-30 -msg "$result"}	
		if {[catch {eval ::TE::DES::run_sw_project} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-31 -msg "$result"}		
		if {[file exist [glob -nocomplain -directory [pwd] *.bdf]]} {
			if {[catch {eval ::TE::QUART::generate_bsf} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-32 -msg "$result"}
		}		
		if {[catch {eval ::TE::QUART::regenerate_ip} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-33 -msg "$result"}		
		if {[catch {eval ::TE::QUART::execute_project_tcl} result]} {::TE::UTILS::te_msg -type error -id TE_DES-34 -msg "$result"}	
		if {[catch {eval ::TE::QUART::compile_project} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-35 -msg "$result"}		
		
		::TE::UTILS::te_msg -type info -id TE_DES-36 -msg "Run build project (all) -> done"
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
		
		if {$GUI == 2} {start_existing_project $GUI}
		cd ../
	}		
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished project design functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
    
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # software functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
    #--run software project
	proc run_sw_project {} {
		::TE::UTILS::te_msg -msg "\n-----------------------------------------------------------------------"
		if {[file exist $::TE::SOURCE_PATH/software]} {
			::TE::UTILS::te_msg -type info -id TE_DES-37 -msg "Create software project. Please wait ..."		
			if {[catch {eval ::TE::SDK::create_software_files} result]} {::TE::UTILS::te_msg -type error -id TE_DES-38 -msg "$result"}
			if {[file exist ${::TE::SOURCE_PATH}/software/bsp_settings.tcl]} {file copy -force  ${::TE::SOURCE_PATH}/software/bsp_settings.tcl ${::TE::SDK_PATH}}
			if {[catch {eval ::TE::SDK::create_this_bsp} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-39 -msg "$result"}				
			if {[catch {eval ::TE::SDK::create_this_app} result]} 		{::TE::UTILS::te_msg -type error -id TE_DES-40 -msg "$result"}
			if {[catch {eval ::TE::SDK::app_make} result]} 				{::TE::UTILS::te_msg -type error -id TE_DES-41 -msg "$result"}	
			if {[catch {eval ::TE::SDK::generate_hex_file} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-42 -msg "$result"}
			::TE::UTILS::te_msg -type info -id TE_DES-43 -msg "Create software project -> done"
		} else {
			::TE::UTILS::te_msg -type warning -id TE_DES-57 -msg "SDK sources files not found: ${::TE::SOURCE_PATH}/software"
		}
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished software functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
 
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # export project functions
  # -----------------------------------------------------------------------------------------------------------------------------------------
	#--------------------------------
	#generate source files
	proc generate_source_files {} {
		::TE::UTILS::te_msg -msg "\n-----------------------------------------------------------------------"
		::TE::UTILS::te_msg -type info -id TE_DES-39 -msg "Generate source files. Please wait ..."
		if {[catch {eval ::TE::UTILS::clean_source_files} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-56 -msg "$result"}
		if {[catch {eval ::TE::EXP::create_source_folder} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-44 -msg "$result"}
		if {[catch {eval ::TE::EXP::generate_tcl_proj} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-45 -msg "$result"}
		if {[catch {eval ::TE::EXP::generate_tcl_qsys} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-47 -msg "$result"}
		if {[catch {eval ::TE::EXP::export_project_files} result]} 	{::TE::UTILS::te_msg -type error -id TE_DES-49 -msg "$result"}
		if {[catch {eval ::TE::EXP::export_software_files} result]} {::TE::UTILS::te_msg -type error -id TE_DES-50 -msg "$result"}
		::TE::UTILS::te_msg -type info -id TE_DES-51 -msg "Generate source files -> done"
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}
	
	#--------------------------------
	#export project with prebuilt files
	proc export_project_preb {} {
		::TE::UTILS::te_msg -msg "\n-----------------------------------------------------------------------"
		::TE::UTILS::te_msg -type info -id TE_DES-52 -msg "Export project (preb). Please wait ..."		
		if {[catch {eval ::TE::EXP::generate_prebuilt_files} result]} {::TE::UTILS::te_msg -type error -id TE_DES-54 -msg "$result"}
		::TE::UTILS::te_msg -type info -id TE_DES-55 -msg "Export project (preb) -> done"
		::TE::UTILS::te_msg -msg "-----------------------------------------------------------------------"
	}
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished export project functions
  # -----------------------------------------------------------------------------------------------------------------------------------------


  }
  ::TE::UTILS::te_msg -type info -msg "(TE) Load designs script finished"
}