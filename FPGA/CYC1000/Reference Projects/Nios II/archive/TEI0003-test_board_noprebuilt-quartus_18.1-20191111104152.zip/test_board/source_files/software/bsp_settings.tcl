######################################################################
#
#  This is a generated Tcl script exported
#  by a user of the Altera Nios II BSP Editor.
#
#  It can be used with the Altera 'nios2-bsp' shell script '--script'
#  option to customize a new or existing BSP.
#
######################################################################
 
######################################################################
#
# Exported Setting Changes 
#
######################################################################
 
set_setting hal.enable_reduced_device_drivers true
set_setting hal.enable_small_c_library true
set_setting hal.enable_c_plus_plus false
 
