# Copyright (C) 2019  Intel Corporation. All rights reserved.
# Your use of Intel Corporation's design tools, logic functions 
# and other software and tools, and any partner logic 
# functions, and any output files from any of the foregoing 
# (including device programming or simulation files), and any 
# associated documentation or information are expressly subject 
# to the terms and conditions of the Intel Program License 
# Subscription Agreement, the Intel Quartus Prime License Agreement,
# the Intel FPGA IP License Agreement, or other applicable license
# agreement, including, without limitation, that your use is for
# the sole purpose of programming logic devices manufactured by
# Intel and sold by Intel or its authorized distributors.  Please
# refer to the applicable agreement for further details, at
# https://fpgasoftware.intel.com/eula.

# Quartus Prime: Generate Tcl File for Project
# File: test_board.tcl
# Generated on: Thu Oct 01 11:08:44 2020

# Load Quartus Prime Tcl Project package
package require ::quartus::project

set need_to_close_project 0
set make_assignments 1

# Check that the right project is open
if {[is_project_open]} {
	if {[string compare $quartus(project) "test_board"]} {
		puts "Project test_board is not open"
		set make_assignments 0
	}
} else {
	# Only open if not already open
	if {[project_exists test_board]} {
		project_open -revision test_board test_board
	} else {
		project_new -revision test_board test_board
	}
	set need_to_close_project 1
}

# Make assignments
if {$make_assignments} {
# #TE_MOD# 	set_global_assignment -name FAMILY "Cyclone 10 LP" 
# #TE_MOD# 	set_global_assignment -name DEVICE 10CL025YU256C8G 
	set_global_assignment -name ORIGINAL_QUARTUS_VERSION 18.1.0
	set_global_assignment -name PROJECT_CREATION_TIME_DATE "11:47:22  MARCH 18, 2019"
	set_global_assignment -name LAST_QUARTUS_VERSION "19.1.0 SP0.02std Lite Edition"
	set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output_files
	set_global_assignment -name MIN_CORE_JUNCTION_TEMP 0
	set_global_assignment -name MAX_CORE_JUNCTION_TEMP 85
	set_global_assignment -name DEVICE_FILTER_PACKAGE UFBGA
	set_global_assignment -name DEVICE_FILTER_PIN_COUNT 256
	set_global_assignment -name DEVICE_FILTER_SPEED_GRADE 8
	set_global_assignment -name ERROR_CHECK_FREQUENCY_DIVISOR 256
	set_global_assignment -name ENABLE_OCT_DONE OFF
	set_global_assignment -name USE_CONFIGURATION_DEVICE OFF
	set_global_assignment -name CRC_ERROR_OPEN_DRAIN OFF
	set_global_assignment -name STRATIX_DEVICE_IO_STANDARD "3.3-V LVTTL"
	set_global_assignment -name OUTPUT_IO_TIMING_NEAR_END_VMEAS "HALF VCCIO" -rise
	set_global_assignment -name OUTPUT_IO_TIMING_NEAR_END_VMEAS "HALF VCCIO" -fall
	set_global_assignment -name OUTPUT_IO_TIMING_FAR_END_VMEAS "HALF SIGNAL SWING" -rise
	set_global_assignment -name OUTPUT_IO_TIMING_FAR_END_VMEAS "HALF SIGNAL SWING" -fall
	set_global_assignment -name PROJECT_IP_REGENERATION_POLICY ALWAYS_REGENERATE_IP
	set_global_assignment -name POWER_PRESET_COOLING_SOLUTION "23 MM HEAT SINK WITH 200 LFPM AIRFLOW"
	set_global_assignment -name POWER_BOARD_THERMAL_MODEL "NONE (CONSERVATIVE)"
	set_global_assignment -name FLOW_ENABLE_POWER_ANALYZER ON
	set_global_assignment -name POWER_DEFAULT_INPUT_IO_TOGGLE_RATE "12.5 %"
	set_global_assignment -name EXTERNAL_FLASH_FALLBACK_ADDRESS 0
	set_global_assignment -name INTERNAL_FLASH_UPDATE_MODE "SINGLE IMAGE WITH ERAM"
	set_global_assignment -name ENABLE_DEVICE_WIDE_RESET ON
	set_global_assignment -name ENABLE_CONFIGURATION_PINS OFF
	set_global_assignment -name PARTITION_NETLIST_TYPE SOURCE -section_id Top
	set_global_assignment -name PARTITION_FITTER_PRESERVATION_LEVEL PLACEMENT_AND_ROUTING -section_id Top
	set_global_assignment -name PARTITION_COLOR 16764057 -section_id Top
	set_global_assignment -name ENABLE_BOOT_SEL_PIN OFF
	set_global_assignment -name CYCLONEIII_CONFIGURATION_DEVICE EPCQ16
	set_global_assignment -name VHDL_FILE hdl/shift_reg_seq.vhd
	set_global_assignment -name VHDL_FILE hdl/pwm_seq.vhd
	set_global_assignment -name VHDL_FILE hdl/pwm_gen.vhd
	set_global_assignment -name VHDL_FILE hdl/knightrider.vhd
	set_global_assignment -name VHDL_FILE hdl/differentiator.vhd
	set_global_assignment -name VHDL_FILE hdl/control_mux.vhd
	set_global_assignment -name VHDL_FILE hdl/clk_divisor.vhd
	set_global_assignment -name VHDL_FILE hdl/case_state_seq.vhd
	set_global_assignment -name SDC_FILE test_board.out.sdc
	set_global_assignment -name QIP_FILE NIOS_test_board/synthesis/NIOS_test_board.qip
	set_global_assignment -name BDF_FILE test_board.bdf
	set_location_assignment PIN_N6 -to user_btn
	set_location_assignment PIN_M6 -to led_out[0]
	set_location_assignment PIN_T4 -to led_out[1]
	set_location_assignment PIN_T3 -to led_out[2]
	set_location_assignment PIN_R3 -to led_out[3]
	set_location_assignment PIN_T2 -to led_out[4]
	set_location_assignment PIN_R4 -to led_out[5]
	set_location_assignment PIN_N5 -to led_out[6]
	set_location_assignment PIN_N3 -to led_out[7]
	set_location_assignment PIN_M2 -to clk_12mhz
	set_location_assignment PIN_A7 -to sdram_wen
	set_location_assignment PIN_B7 -to sdram_rasn
	set_location_assignment PIN_B13 -to sdram_dqm[0]
	set_location_assignment PIN_D12 -to sdram_dqm[1]
	set_location_assignment PIN_A10 -to sdram_dq[1]
	set_location_assignment PIN_B10 -to sdram_dq[0]
	set_location_assignment PIN_B11 -to sdram_dq[2]
	set_location_assignment PIN_A11 -to sdram_dq[3]
	set_location_assignment PIN_A12 -to sdram_dq[4]
	set_location_assignment PIN_D9 -to sdram_dq[5]
	set_location_assignment PIN_B12 -to sdram_dq[6]
	set_location_assignment PIN_C9 -to sdram_dq[7]
	set_location_assignment PIN_D11 -to sdram_dq[8]
	set_location_assignment PIN_E11 -to sdram_dq[9]
	set_location_assignment PIN_A15 -to sdram_dq[10]
	set_location_assignment PIN_E9 -to sdram_dq[11]
	set_location_assignment PIN_D14 -to sdram_dq[12]
	set_location_assignment PIN_F9 -to sdram_dq[13]
	set_location_assignment PIN_C14 -to sdram_dq[14]
	set_location_assignment PIN_A14 -to sdram_dq[15]
	set_location_assignment PIN_A6 -to sdram_csn
	set_location_assignment PIN_B14 -to sdram_clk
	set_location_assignment PIN_F8 -to sdram_cke
	set_location_assignment PIN_C8 -to sdram_casn
	set_location_assignment PIN_A4 -to sdram_ba[0]
	set_location_assignment PIN_B6 -to sdram_ba[1]
	set_location_assignment PIN_A3 -to sdram_addr[0]
	set_location_assignment PIN_B5 -to sdram_addr[1]
	set_location_assignment PIN_B4 -to sdram_addr[2]
	set_location_assignment PIN_B3 -to sdram_addr[3]
	set_location_assignment PIN_C3 -to sdram_addr[4]
	set_location_assignment PIN_D3 -to sdram_addr[5]
	set_location_assignment PIN_E6 -to sdram_addr[6]
	set_location_assignment PIN_E7 -to sdram_addr[7]
	set_location_assignment PIN_D6 -to sdram_addr[8]
	set_location_assignment PIN_D8 -to sdram_addr[9]
	set_location_assignment PIN_A5 -to sdram_addr[10]
	set_location_assignment PIN_E8 -to sdram_addr[11]
	set_location_assignment PIN_R7 -to uart_txd
	set_location_assignment PIN_T7 -to uart_rxd
	set_location_assignment PIN_F3 -to spi_g_sen_clk
	set_location_assignment PIN_D1 -to spi_g_sen_csn
	set_location_assignment PIN_G1 -to spi_g_sen_miso
	set_location_assignment PIN_G2 -to spi_g_sen_mosi
	set_instance_assignment -name PARTITION_HIERARCHY root_partition -to | -section_id Top

	# Commit assignments
	export_assignments

	# Close project
	if {$need_to_close_project} {
		project_close
	}
}

