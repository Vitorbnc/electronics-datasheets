## Generated SDC file "test_board.out.sdc"

## Copyright (C) 2019  Intel Corporation. All rights reserved.
## Your use of Intel Corporation's design tools, logic functions 
## and other software and tools, and any partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Intel Program License 
## Subscription Agreement, the Intel Quartus Prime License Agreement,
## the Intel FPGA IP License Agreement, or other applicable license
## agreement, including, without limitation, that your use is for
## the sole purpose of programming logic devices manufactured by
## Intel and sold by Intel or its authorized distributors.  Please
## refer to the applicable agreement for further details, at
## https://fpgasoftware.intel.com/eula.


## VENDOR  "Altera"
## PROGRAM "Quartus Prime"
## VERSION "Version 19.1.0 Build 670 09/22/2019 Patches 0.02std SJ Lite Edition"

## DATE    "Tue May 12 16:16:17 2020"

##
## DEVICE  "10CL025YU256C8G"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

create_clock -name {altera_reserved_tck} -period 100.000 -waveform { 0.000 50.000 } [get_ports {altera_reserved_tck}]
create_clock -name {clk_12mhz} -period 83.333 -waveform { 0.000 41.666 } [get_ports {clk_12mhz}]


#**************************************************************
# Create Generated Clock
#**************************************************************

create_generated_clock -name {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]} -source [get_pins {inst|pll|sd1|pll7|inclk[0]}] -duty_cycle 50/1 -multiply_by 25 -divide_by 6 -master_clock {clk_12mhz} [get_pins {inst|pll|sd1|pll7|clk[0]}] 
create_generated_clock -name {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[1]} -source [get_pins {inst|pll|sd1|pll7|inclk[0]}] -duty_cycle 50/1 -multiply_by 25 -divide_by 6 -phase -90.000 -master_clock {clk_12mhz} [get_pins {inst|pll|sd1|pll7|clk[1]}] 


#**************************************************************
# Set Clock Latency
#**************************************************************



#**************************************************************
# Set Clock Uncertainty
#**************************************************************

set_clock_uncertainty -rise_from [get_clocks {altera_reserved_tck}] -rise_to [get_clocks {altera_reserved_tck}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {altera_reserved_tck}] -fall_to [get_clocks {altera_reserved_tck}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {altera_reserved_tck}] -rise_to [get_clocks {altera_reserved_tck}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {altera_reserved_tck}] -fall_to [get_clocks {altera_reserved_tck}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {clk_12mhz}] -setup 0.110  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {clk_12mhz}] -hold 0.090  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {clk_12mhz}] -setup 0.110  
set_clock_uncertainty -rise_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {clk_12mhz}] -hold 0.090  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {clk_12mhz}] -setup 0.110  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -rise_to [get_clocks {clk_12mhz}] -hold 0.090  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {clk_12mhz}] -setup 0.110  
set_clock_uncertainty -fall_from [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -fall_to [get_clocks {clk_12mhz}] -hold 0.090  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -setup 0.090  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -hold 0.110  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -setup 0.090  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -hold 0.110  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {clk_12mhz}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {clk_12mhz}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -setup 0.090  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -hold 0.110  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -setup 0.090  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {NIOS_test_board:inst|NIOS_test_board_pll:pll|NIOS_test_board_pll_altpll_rk92:sd1|wire_pll7_clk[0]}] -hold 0.110  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -rise_to [get_clocks {clk_12mhz}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {clk_12mhz}] -fall_to [get_clocks {clk_12mhz}]  0.020  


#**************************************************************
# Set Input Delay
#**************************************************************



#**************************************************************
# Set Output Delay
#**************************************************************



#**************************************************************
# Set Clock Groups
#**************************************************************

set_clock_groups -asynchronous -group [get_clocks {altera_reserved_tck}] 


#**************************************************************
# Set False Path
#**************************************************************

set_false_path -to [get_keepers {*altera_std_synchronizer:*|din_s1}]
set_false_path -to [get_pins -nocase -compatibility_mode {*|alt_rst_sync_uq1|altera_reset_synchronizer_int_chain*|clrn}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_oci_break:the_NIOS_test_board_nios2_cpu_nios2_oci_break|break_readreg*}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr*}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_oci_debug:the_NIOS_test_board_nios2_cpu_nios2_oci_debug|*resetlatch}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr[33]}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_oci_debug:the_NIOS_test_board_nios2_cpu_nios2_oci_debug|monitor_ready}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr[0]}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_oci_debug:the_NIOS_test_board_nios2_cpu_nios2_oci_debug|monitor_error}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr[34]}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_ocimem:the_NIOS_test_board_nios2_cpu_nios2_ocimem|*MonDReg*}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr*}]
set_false_path -from [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_tck:the_NIOS_test_board_nios2_cpu_debug_slave_tck|*sr*}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_sysclk:the_NIOS_test_board_nios2_cpu_debug_slave_sysclk|*jdo*}]
set_false_path -from [get_keepers {sld_hub:*|irf_reg*}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_debug_slave_wrapper:the_NIOS_test_board_nios2_cpu_debug_slave_wrapper|NIOS_test_board_nios2_cpu_debug_slave_sysclk:the_NIOS_test_board_nios2_cpu_debug_slave_sysclk|ir*}]
set_false_path -from [get_keepers {sld_hub:*|sld_shadow_jsm:shadow_jsm|state[1]}] -to [get_keepers {*NIOS_test_board_nios2_cpu:*|NIOS_test_board_nios2_cpu_nios2_oci:the_NIOS_test_board_nios2_cpu_nios2_oci|NIOS_test_board_nios2_cpu_nios2_oci_debug:the_NIOS_test_board_nios2_cpu_nios2_oci_debug|monitor_go}]


#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************

set_max_delay -from [get_registers {*altera_avalon_st_clock_crosser:*|in_data_buffer*}] -to [get_registers {*altera_avalon_st_clock_crosser:*|out_data_buffer*}] 100.000
set_max_delay -from [get_registers *] -to [get_registers {*altera_avalon_st_clock_crosser:*|altera_std_synchronizer_nocut:*|din_s1}] 100.000


#**************************************************************
# Set Minimum Delay
#**************************************************************

set_min_delay -from [get_registers {*altera_avalon_st_clock_crosser:*|in_data_buffer*}] -to [get_registers {*altera_avalon_st_clock_crosser:*|out_data_buffer*}] -100.000
set_min_delay -from [get_registers *] -to [get_registers {*altera_avalon_st_clock_crosser:*|altera_std_synchronizer_nocut:*|din_s1}] -100.000


#**************************************************************
# Set Input Transition
#**************************************************************



#**************************************************************
# Set Net Delay
#**************************************************************

set_net_delay -max -value_multiplier 0.800 -get_value_from_clock_period dst_clock_period -from [get_registers {*altera_avalon_st_clock_crosser:*|in_data_buffer*}] -to [get_registers {*altera_avalon_st_clock_crosser:*|out_data_buffer*}]
set_net_delay -max -value_multiplier 0.800 -get_value_from_clock_period dst_clock_period -from [get_registers *] -to [get_registers {*altera_avalon_st_clock_crosser:*|altera_std_synchronizer_nocut:*|din_s1}]
