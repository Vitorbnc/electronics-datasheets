# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Beendorfer Straße 23    *
# --   *   32609 Hüllhorst         *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2020/01/29 | $Author: Dück, Thomas
# -- - modified proc export_project_files
# ------------------------------------------
# -- $Date: 2019/10/25 | $Author: Dück, Thomas
# -- - initial release
# --------------------------------------------------------------------
# --------------------------------------------------------------------

namespace eval ::TE {
  namespace eval EXP {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # export functions
  # -----------------------------------------------------------------------------------------------------------------------------------------		
	#--------------------------------
	#create folder for source files
	proc create_source_folder {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-01 -msg "Create new project source folder. Please wait ..."	
		if {![file exists ${::TE::SOURCE_PATH}/quartus]} {
				file mkdir ${::TE::SOURCE_PATH}/quartus
		}
		if {![file exists ${::TE::SOURCE_PATH}/software]} {
				file mkdir ${::TE::SOURCE_PATH}/software
		}		
		::TE::UTILS::te_msg -type info -id TE_EXP-02 -msg "Create new project source folder -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#copy quartus project files to source_files/quartus
	proc export_project_files {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-03 -msg "Copy quartus project files to source folder. Please wait ..."
		#search quartus design files
		set qdir [glob -tail -directory ${::TE::QPROJ_PATH}/ *.bdf *.sdc *.vhd *.v *.sv *.tcl *.cof *.ip]
		set subdir [glob -nocomplain -tail -directory ${::TE::QPROJ_PATH}/ ip ip/* hdl hdl/*]
		foreach dir $subdir {
			if {(![string match -nocase *${::TE::QSYS_NAME}* $dir] || ${::TE::QSYS_NAME} eq "") && ![string match -nocase "*/db" $dir] } {
				if {[file isdirectory  ${::TE::QPROJ_PATH}/${dir}]} {
					file mkdir ${::TE::QPROJ_SOURCE_PATH}/${dir}
					if {[string match -nocase "ip/*" ${dir}] && [glob -nocomplain -tail -directory ${::TE::QPROJ_PATH}/ ${dir}/*.ip] eq ""} {
						set tmpdir [glob -nocomplain -tail -directory ${::TE::QPROJ_PATH}/ ${dir}/*] ;#search source files from subdirectories
					} else {
						set tmpdir [glob -nocomplain -tail -directory ${::TE::QPROJ_PATH}/ ${dir}/*.ip ${dir}/*.v ${dir}/*.sv ${dir}/*.vhd ${dir}/*.tcl ${dir}/*.qprs] ;#search source files from subdirectories
					}

					foreach dir $tmpdir {
						lappend qdir $dir
					}
				}
			}
		}
	
		#copy quartus design files
		foreach filedir $qdir {
			file copy -force ${::TE::QPROJ_PATH}/$filedir ${::TE::QPROJ_SOURCE_PATH}/$filedir	
		}
		::TE::UTILS::te_msg -type info -id TE_EXP-04 -msg "Copy quartus project files to source folder -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
		
	#--------------------------------
	#copy software files to source_files/software
	proc export_software_files {project} {
		::TE::UTILS::te_msg -type info -id TE_EXP-05 -msg "Copy software files for '$project' to source folder. Please wait ..."
		file mkdir ${::TE::SDK_SOURCE_PATH}/${project}
		set sdkdir [glob -tail -nocomplain -directory ${::TE::SDK_PATH}/${project}/ *.c *.h *.xml]
		foreach filedir $sdkdir { 
			if {[catch {file copy -force ${::TE::SDK_PATH}/${project}/$filedir ${::TE::SDK_SOURCE_PATH}/${project}/$filedir} result]} {
				::TE::UTILS::te_msg -type error -id TE_EXP-14 -msg "Error on copying $filedir: $result"
			} else {
				::TE::UTILS::te_msg -type info -id TE_EXP-06 -msg " - $filedir copied."
			}
		}	
		::TE::UTILS::te_msg -type info -id TE_EXP-07 -msg "Copy software files '$project' to source folder -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
	#generate <project>.tcl
	proc generate_tcl_proj {} {
		::TE::UTILS::te_msg -type info -id TE_EXP-08 -msg "Generate ${::TE::QPROJ_NAME}.tcl file. Please wait ..."
		::quartus::pjc_tcl_project_open ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
		set command ::quartus::pjc_tcl_project_generate_tcl_file    	
		lappend command ${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
		lappend command overwrite	
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_EXP-09 -msg "Results on command: $command:\n$result"
		}
		::quartus::pjc_tcl_project_close
		if {[file tail [pwd]]=="quartus"} {
			cd ../
		}
		::TE::UTILS::te_msg -type info -id TE_EXP-10 -msg "Generate ${::TE::QPROJ_NAME}.tcl file -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
	#generate <qsys>.tcl
	proc generate_tcl_qsys {} {
		foreach qsysname ${::TE::QSYS_NAME} {
			::TE::UTILS::te_msg -type info -id TE_EXP-11 -msg "Generate $qsysname.tcl file. Please wait ..."
			set command exec
			lappend command ${::TE::QROOTPATH}sopc_builder/bin/qsys-generate${::TE::WIN_EXE}
			lappend command ${::TE::QPROJ_PATH}/${qsysname}.qsys
			lappend command --export-qsys-script
			if {${::TE::QEDITION} == "Pro"} {			
				lappend command --quartus-project=${::TE::QPROJ_PATH}/${::TE::QPROJ_NAME}
			}
			[catch {eval $command} result]		
			::TE::UTILS::report $result $command TE_EXP-12	
			::TE::UTILS::te_msg -type info -id TE_EXP-13 -msg "Generate $qsysname.tcl file -> done"
		}
		if {${::TE::QEDITION} == "Pro"} {
			set subsystem_tcl [list]
			foreach qsysname ${::TE::QSYS_NAME} {
				set fp [open "${::TE::QPROJ_PATH}/${qsysname}.tcl" r]
				set file_data [read $fp]
				close $fp
				set file_data [split $file_data "\n"]
				foreach line $file_data {
					if {[string match "*set_module_property NAME *" $line]} {
						foreach qsys_subsystem ${::TE::QSYS_NAME} {
							if {[string match "*$qsys_subsystem*" $line] && $qsysname ne $qsys_subsystem} {
								lappend subsystem_tcl ${qsys_subsystem}
							}
						}
					}
				}
			}
			foreach delete_file $subsystem_tcl {
				file delete ${::TE::QPROJ_PATH}/${delete_file}.tcl
			}
		}
		::TE::UTILS::te_msg -msg "------------------------------"
	}		
		
	#--------------------------------
	#generate prebuilt files (*.pof, *.jic)
	proc generate_prebuilt_files {shortnamelist} {
		::TE::UTILS::te_msg -type info -id TE_EXP-18 -msg "Generate prebuilt files. Please wait ..."		
		set tmp_folder [clock format [clock seconds] -format %Y%m%d%H%M%S]
		#set global variables to correct device variant from device_list
		set short_list [list] 
		set id_list [list]
		if {$shortnamelist eq "all"} {
			if {[catch {eval ::TE::UTILS::clean_prebuilt "all"} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-19 -msg "Error on ::TE::UTILS::clean_prebuilt:\n$result"}	
		}
		
		foreach line ${::TE::BOARD_DEFINITION} {
			if {![string match *[lindex $line 4]* $short_list] && ![string match *SHORTNAME* $line] && $shortnamelist eq "all"} {			
				lappend short_list [lindex $line 4]
				lappend id_list [lindex $line 0]
			} elseif {$shortnamelist ne "all"} {
				foreach shortname $shortnamelist {
					if {![string match *[lindex $line 4]* $short_list] && ![string match *SHORTNAME* $line] && [string match *[lindex $line 4]* $shortname]} {		
						lappend short_list [lindex $line 4]					
						lappend id_list [lindex $line 0]	
						if {[catch {eval ::TE::UTILS::clean_prebuilt [lindex $line 4]} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-35 -msg "Error on ::TE::UTILS::clean_prebuilt:\n$result"}
					}
				}
			}
		}
	
		set ::TE::QPROJ_PATH ${::TE::BASEFOLDER}/$tmp_folder/quartus
		set ::TE::SDK_PATH ${::TE::BASEFOLDER}/$tmp_folder/software
		set ::TE::sdksrcback "../../.."
		if {${::TE::QEDITION} eq "Pro"} { set sopcdir "${::TE::BASEFOLDER}/$tmp_folder/quartus/${::TE::NIOS_SOPC_FILE_NAME}" } else { set sopcdir "${::TE::BASEFOLDER}/$tmp_folder/quartus" }
		
		foreach id $id_list {
			set prebstarttime [clock seconds]
			set ::TE::cntprebinfo 0
			set ::TE::cntprebwarning 0
			set ::TE::cntprebcriticalwarning 0
			set ::TE::cntpreberror 0		
			
			file mkdir $tmp_folder
			cd $tmp_folder
						
			if {[catch {eval ::TE::INIT::init_board $id} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-22 -msg "$result"}

			#create and compile project and software
			if {[catch {eval ::TE::DES::run_build_project} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-23 -msg "Error on ::TE::DES::run_build_project:\n$result"}

			#create prebuilt subfolders if not exist
			if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files]} {
				file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files
			}
			if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware] && ${::TE::QSYS_SRC_NAME} ne ""} {
				file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware
			}
			if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software] && ${::TE::SDK_SRC_NAME} ne "no_project" } {
				file mkdir ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software
			}				

			#copy generated prebuilt files to prebuilt subfolders
			set prebfile_list [glob -nocomplain -directory ${::TE::QPROJ_PATH}/output_files/ *.sof *.pof *.jic]
			if {[string match -nocase *.jic* $prebfile_list]} {
				set copylist [glob -nocomplain -directory ${::TE::QPROJ_PATH}/output_files/ *.sof *.jic]
			} elseif {![string match -nocase *.pof* $prebfile_list]} {
				set copylist [glob -nocomplain -directory ${::TE::QPROJ_PATH}/output_files/ *.sof]
			 } else {
				set copylist [glob -nocomplain -directory ${::TE::QPROJ_PATH}/output_files/ *.pof]
			}
			
			foreach preb_source $copylist {
				regexp {(\w+)\.(\w+)} [file tail $preb_source] matched name type
				set new_name ${name}-${::TE::SHORTNAME}.${type}
				if {![file exist ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/${new_name}]} {	
					if {[catch {file copy -force [glob  ${::TE::QPROJ_PATH}/output_files/${matched}] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-24 -msg "$result"}
					if {[catch {file rename ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${matched} ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${new_name}} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-25 -msg "$result"}
				} else {post_message -type warning "File ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/programming_files/${new_name} already exist."}
			}
			if { ${::TE::QSYS_SRC_NAME} ne "" } {
				if {[catch {file copy -force [glob -directory  $sopcdir *.sopcinfo] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/hardware} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-26 -msg "$result"}
			}
			if { ${::TE::SDK_SRC_NAME} ne "no_project" } {
				if {[catch {file copy -force [glob -directory  ${::TE::SDK_PATH} /**/*.elf] ${::TE::PREBUILT_PATH}/${::TE::SHORTNAME}/software} result]} {::TE::UTILS::te_msg -type error -id TE_EXP-27 -msg "$result"}
			}
			
			set prebstoptime [clock seconds]
			set ::TE::prebtime [expr ${prebstoptime} -${prebstarttime}] 
			if {[catch {eval ::TE::UTILS::report_prebuilt_hw_summary} result]} 	{::TE::UTILS::te_msg -type error -id TE_EXP-28 -msg "Error on ::TE::UTILS::report_prebuilt_hw_summary:\n$result"}

			
			cd ${::TE::BASEFOLDER}
			file delete -force $tmp_folder			
		}
		
		set ::TE::QPROJ_PATH ${::TE::BASEFOLDER}/quartus
		set ::TE::SDK_PATH ${::TE::BASEFOLDER}/software
		set ::TE::sdksrcback "../.."

		::TE::UTILS::te_msg -type info -id TE_EXP-29 -msg "Export prebuilt files -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
    #--zip_project: 
	proc zip_project {ZIPNAME EXCLUDELIST} {
		::TE::UTILS::te_msg -type info -id TE_EXP-30 -msg "Zip Project. Please wait ..."	
		#remove old backup project copy
		set sourcepath [string trim $TE::QPROJ_PATH "quartus"]
		set destinationpath ${TE::BACKUP_PATH}/${TE::QPROJ_SRC_NAME}
		if {[file exists ${destinationpath}]} { 
			file delete -force ${destinationpath}  
		}
		#create new destination folder
		file mkdir ${destinationpath}
		
		#get all files
		set filelist [ glob ${sourcepath}*]
		#remove backup folder
		set findex [lsearch $filelist *backup]
		set filelist [lreplace $filelist[set filelist {}] $findex $findex]
      
		foreach el $filelist {
			file copy -force ${el} ${destinationpath}
		}

		foreach el $EXCLUDELIST {
			set find ""
			if {[catch {set find [glob -join -dir $destinationpath $el]}] && [catch {set find [glob -type hidden -join -dir $destinationpath $el]}]} {
				::TE::UTILS::te_msg -type info -id TE_EXP-31 -msg "$el doesn't exist."
			} else {
				::TE::UTILS::te_msg -type info -id TE_EXP-32 -msg "Excluded from backup: $find"
				file delete -force $find
			}
		}
				
		#zip project	
		set command exec
		if {[file exists $::quartus(binpath)7z${::TE::WIN_EXE}]} {
			lappend command 7z${::TE::WIN_EXE}
			lappend command a
			lappend command -tzip 
			lappend command -o${::TE::BACKUP_PATH}
			lappend command "${ZIPNAME}.zip"
			lappend command ${TE::BACKUP_PATH}/${TE::QPROJ_SRC_NAME}
			lappend command -r		
		} else {
			lappend command zip${::TE::WIN_EXE}
			lappend command -r
			lappend command ${ZIPNAME}.zip
			lappend command ${TE::QPROJ_SRC_NAME} 
	
		}
				
		cd ${::TE::BACKUP_PATH}
		catch {eval $command} result
		::TE::UTILS::te_msg -type info -id TE_EXP-33 -msg "Result of command $command:\n$result" 
		cd ${::TE::BASEFOLDER}
		
		#remove project copy
		if {[file exists ${destinationpath}]} { 
			file delete -force ${destinationpath}
		}

		::TE::UTILS::te_msg -type info -id TE_EXP-34 -msg "Zip Project -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
    }
	
  #-----------------------------------------------------------------------------------------------------------------------------------------
  # finished export functions
  # -----------------------------------------------------------------------------------------------------------------------------------------	
  }
  ::TE::UTILS::te_msg -type info -msg "(TE) Load export script finished"
}


