--============================================================================= 
--
-- Mode Controller
--
-- Toggles through choosing 1 out of 5 possible LED sequence modes
--
--============================================================================= 

library ieee;
	use ieee.std_logic_1164.all;
	use ieee.std_logic_unsigned.all;

entity control_mux is
	port (		
		clk     	: in 	std_logic;
		resetn   	: in 	std_logic;
		user_btn	: in	std_logic;
		mode   		: out	std_logic_vector(2 downto 0);
		led_in		: in	std_logic_vector(39 downto 0);
		led_out		: out	std_logic_vector(7 downto 0)
	);
end entity;

architecture behavioural of control_mux is

	signal cnt 		: 		std_logic_vector(2 downto 0) := "001";
	signal reset	:		std_logic :='1';
	signal keyout	: 		std_logic;
	signal key_db	: 		std_logic := '0';
	signal dbcnt 	: 		integer range 0 to 63 := 0;
	
begin
-------------------------------------------------------------------------------
-- debounce key
-------------------------------------------------------------------------------
   process 
	begin
      wait until rising_edge(clk);
      if (user_btn=key_db) then 
			dbcnt <= 0;
      else                   
			dbcnt <= dbcnt+1;
      end if;
      if (dbcnt=63) then 
			key_db <= user_btn; 
      end if;
   end process;
	
   keyout <= key_db;

-------------------------------------------------------------------------------
-- toggle through states
-------------------------------------------------------------------------------
	process(keyout, resetn, reset)
	begin
		if resetn = '0' or reset = '0' then
			cnt <= "001";
		elsif falling_edge(keyout) then
			cnt <= cnt + 1;
			if cnt >= "101" then
				cnt <= "001";
			end if;
		end if;
	end process;
	
-------------------------------------------------------------------------------
-- Pass LED sequence to LEDs depending on mode
-------------------------------------------------------------------------------
	process(cnt, led_in)
	begin		
		case cnt is	
			when "001"  => led_out <= led_in (39 downto 32);
			when "010" 	=> led_out <= led_in (31 downto 24);
			when "011" 	=> led_out <= led_in (23 downto 16);
			when "100" 	=> led_out <= led_in (15 downto 8);
			when "101" 	=> led_out <= led_in (7 downto 0);
			when others => led_out <="00000000";
		end case;
	end process;
	
	reset <= '0' when led_in (39 downto 32) = "11111111" else
				'1';
	mode <= cnt;

end architecture;