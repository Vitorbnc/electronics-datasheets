# --------------------------------------------------------------------
# --   *****************************
# --   *   Trenz Electronic GmbH   *
# --   *   Beendorfer Straße 23    *
# --   *   32609 Hüllhorst         *
# --   *   Germany                 *
# --   *****************************
# --------------------------------------------------------------------
# -- $Author: Dück, Thomas $
# -- $Email: t.dueck@trenz-electronic.de $
# --------------------------------------------------------------------
# -- Change History:
# ------------------------------------------
# -- $Date: 2019/10/25  | $Author: Thomas Dück
# -- - initial release
# ------------------------------------------
# -- $Date: 2020/02/12  | $Author: Thomas Dück
# -- - using *.xml template for generating software project
# ------------------------------------------
# -- $Date: 2020/03/24  | $Author: Thomas Dück
# -- - add download_elf function
# ------------------------------------------
# -- $Date: 2020/06/22  | $Author: Thomas Dück
# -- - add modify_sdk_files function
# -- - modified download_elf function
# ------------------------------------------
# -- $Date: 2021/06/10  | $Author: Thomas Dück
# -- - removed modify_sdk_files function
# -- - bugfixes
# --------------------------------------------------------------------
# --------------------------------------------------------------------
namespace eval ::TE {
	variable sdksrcback "../.." ;# needed to change source file path in create-this-app file
  namespace eval SDK {
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # sdk functions
  # -----------------------------------------------------------------------------------------------------------------------------------------		
	#--------------------------------
    #--create software files
	proc create_software_files {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-01 -msg "Create software files. Please wait ...\n \
        project:  ${::TE::SDK_SRC_NAME} \n \
        cpu-name: ${::TE::QSYS_CPU_NAME} \n \
        elf-name: ${::TE::SDK_SRC_NAME}.elf "
		
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command nios2-swexample-create${::TE::WIN_EXE}
		if {${::TE::QEDITION} == "Pro"} {
			lappend command --sopc-file=../quartus/${::TE::QSYS_SOPC_FILE_NAME}/${::TE::QSYS_SOPC_FILE_NAME}.sopcinfo
		} else {
			lappend command --sopc-file=../quartus/${::TE::QSYS_SOPC_FILE_NAME}.sopcinfo
		}
		lappend command --type=${::TE::SDK_SRC_NAME}
		lappend command --cpu-name=${::TE::QSYS_CPU_NAME}
		lappend command --elf-name=${::TE::SDK_SRC_NAME}.elf
		lappend command --app-dir=./${::TE::SDK_SRC_NAME}
		lappend command --bsp-dir=./${::TE::SDK_SRC_NAME}_bsp
		lappend command --search=${::TE::SDK_SOURCE_PATH}/${::TE::SDK_SRC_NAME}
		if {[catch {eval $command} result]} {
			::TE::UTILS::te_msg -type error -id TE_SDK-02 -msg "Error on command: $command" 
			::TE::UTILS::report $result $command TE_SDK-03
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-04 -msg "Create software files -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}

	#--------------------------------
    #--create bsp	
	proc create_this_bsp {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-05 -msg "Create bsp. Please wait ..."
		# remove carriage return (\r) from file
		set fp_r [open create-this-bsp "r"] 
		set file_data [read $fp_r]
		close $fp_r
		set fp_w [open create-this-bsp "w"]
		fconfigure $fp_w -translation lf
		puts $fp_w "$file_data"
		close $fp_w
		# create bsp
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command ./create-this-bsp --no-make
		[catch {eval $command} result]
		::TE::UTILS::report $result $command TE_SDK-06
		
		::TE::UTILS::te_msg -type Info -id TE_SDK-07 -msg "Create bsp -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}

	#--------------------------------
    #--create app	
	proc create_this_app {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-08 -msg "Create app. Please wait ..."
		#remove carriage return (\r) from file
		set fp_r [open create-this-app "r"] 
		set file_data [read $fp_r]
		close $fp_r
		set fp_w [open create-this-app "w"]
		fconfigure $fp_w -translation lf
		regexp {source_files(.*)} ${::TE::SDK_SOURCE_PATH} sdksrcpath
		regsub -all {\${SOPC_KIT_NIOS2}/examples/software/(\w+)/} $file_data "${::TE::sdksrcback}/$sdksrcpath/${::TE::SDK_SRC_NAME}/" file_data
		puts $fp_w "$file_data"
		close $fp_w
		file copy ${::TE::SDK_SOURCE_PATH}/${::TE::SDK_SRC_NAME}/template.xml ./
		# create app
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command ./create-this-app --no-make
		[catch {eval $command} result]
		::TE::UTILS::report $result $command TE_SDK-09
		::TE::UTILS::te_msg -type Info -id TE_SDK-10 -msg "Create app -> done"
		::TE::UTILS::te_msg -msg  "------------------------------"
	}
	
	#--------------------------------
    #--build software project
	proc app_make {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-11 -msg "Make all - software. Please wait ..."
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command make
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_SDK-12
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-13 -msg "Make all - software -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
    #--generate bsp
	proc generate_bsp {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-25 -msg "Generate BSP. Please wait ..."
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command nios2-bsp-generate-files${::TE::WIN_EXE}
		lappend command --settings=settings.bsp
		lappend command --bsp-dir=./
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_SDK-26
		}
		::TE::UTILS::te_msg -type Info -id TE_SDK-27 -msg "Generate BSP -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}	
	
	#--------------------------------
    #--generate *.hex from *.elf
	proc generate_hex_file {} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-14 -msg "Generate hex file. Please wait ..."
		if {![file exists ${::TE::SDK_PATH}/${::TE::SDK_SRC_NAME}/mem_init]} {
			file mkdir ${::TE::SDK_PATH}/${::TE::SDK_SRC_NAME}/mem_init
		}
		# read ./software/*_bsp/mem_init.mk file
		set fp_r [open ${::TE::SDK_PATH}/${::TE::SDK_SRC_NAME}_bsp/mem_init.mk "r"] 
		set file [read $fp_r]
		close $fp_r
		set file_data [split $file "\n"]
		set name "NA"
		set num "NA"
		# filter file for global settings and pre-initialized memory descriptions
		foreach line $file_data {
			regexp {RESET_ADDRESS \?= (.*)} $line matched reset_address
			regexp {NIOS2_ELF_FORMAT \?= (.*)} $line matched nios2_elf_format

			if {[regexp {\(MEM_(\d+)\)_NAME := (.*)} $line matched num newname]} {
				set oldname $name
				set name $newname
			} elseif {[string match *(MEM_$num)_* $line] && $name ne $oldname} {
				[regexp {\(MEM_(\d+)\)_(.\w+) := (.*)} $line matched sub1 var val]
		
				switch -nocase $var {
					start				{set ${name}_mem_start_address $val}
					end					{set ${name}_mem_end_address $val}
					hex_data_width		{set ${name}_mem_hex_width $val}
					endianness			{set ${name}_mem_endianness $val}
					create_lanes		{set ${name}_mem_create_lanes $val}
					boot_loader_flag	{set ${name}_flash_mem_boot_loader_flag $val}
				}
			} elseif {[string match -nocase "*.PHONY: $name*" $line]} {	
			# generate *.hex files
				if {[info exists ${name}_flash_mem_boot_loader_flag]} {
					set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
					lappend command elf2flash${::TE::WIN_EXE}
					lappend command --base=[subst $${name}_mem_start_address]
					lappend command --end=[subst $${name}_mem_end_address]
					lappend command --reset=$reset_address
					lappend command --input=${::TE::SDK_SRC_NAME}.elf 
					lappend command --output=[subst mem_init/${name}.flash]
					lappend command  --boot=${::TE::QROOTPATH}../nios2eds/components/altera_nios2/boot_loader_cfi.srec
					if {[catch {eval $command} result]} {::TE::UTILS::report $result $command TE_SDK-15}
			
					set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
					lappend command nios2-elf-objcopy${::TE::WIN_EXE}
					lappend command -I srec
					lappend command -O ihex
					lappend command [subst mem_init/${name}.flash]
					lappend command [subst mem_init/${name}.hex]
					if {[catch {eval $command} result]} {::TE::UTILS::report $result $command TE_SDK-16}
			
				} else {
					set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
					lappend command elf2hex${::TE::WIN_EXE}
					lappend command ${::TE::SDK_SRC_NAME}.elf  
					lappend command [subst $${name}_mem_start_address]
					lappend command [subst $${name}_mem_end_address] 
					lappend command --width=[subst $${name}_mem_hex_width]
					lappend command [subst $${name}_mem_endianness]
					lappend command --create-lanes=[subst $${name}_mem_create_lanes]
					lappend command [subst mem_init/${name}.hex]
					if {[catch {eval $command} result]} {::TE::UTILS::report $result $command TE_SDK-17}
				}	
			}
		}
		
		::TE::UTILS::te_msg -type Info -id TE_SDK-18 -msg "Generate hex file -> done"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
	#--------------------------------
    #--downlaod *.elf file to device
	proc download_elf {filedir} {
		::TE::UTILS::te_msg -type Info -id TE_SDK-19 -msg "Download [file tail $filedir]. Please wait ..."
		# set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		# lappend command nios2-download
		# lappend command $filedir
		# lappend command --go
		
		# generate *.srec file from *.elf file
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command nios2-elf-objcopy${::TE::WIN_EXE}
		lappend command $filedir
		lappend command -O srec [string map {".elf" ".srec"} $filedir]
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_SDK-20
		}		
		# download *.srec file to device and run processor
		set command "exec [subst ${::TE::NIOS2_COMMAND_SHELL_PATH}]"
		lappend command nios2-gdb-server${::TE::WIN_EXE}
		lappend command [string map {".elf" ".srec"} $filedir]
		lappend command --go
		if {[catch {eval $command} result]} {
			::TE::UTILS::report $result $command TE_SDK-21
		}
		# delete *.srec file
		file delete -force [string map {".elf" ".srec"} $filedir]
		
		::TE::UTILS::te_msg -type Info -id TE_SDK-22 -msg "Download [file tail $filedir] finished"
		::TE::UTILS::te_msg -msg "------------------------------"
	}
	
  # -----------------------------------------------------------------------------------------------------------------------------------------
  # finished sdk functions
  # -----------------------------------------------------------------------------------------------------------------------------------------	
  }
  ::TE::UTILS::te_msg -type Info -msg "(TE) Load sdk script finished"
}
